
# MIRAGE-DoH Chapter 3: experiments, attack scenarios and performance (v2 artifact)

Every number was produced by the scripts in this repository on the machine described at the end. Traffic is synthetic (mirage_v2/traffic_v2.py), baselines are scikit-learn models rather than the thesis CNN-LSTM, cryptography runs on a CPU, and Classic McEliece is represented by a byte-size model only. These are not the values of Tables 8-12; they show how each mechanism behaves under controlled conditions and where the thesis figures depend on hardware or testbed data not in this repository.


## 1. Claim-by-claim comparison

| Chapter 3 item                                 | thesis value                                                         | this simulation                                                                                                                                              | reading                                                                                           |
|:-----------------------------------------------|:---------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------|
| Detection accuracy vs baselines (Table 8)      | 99.98 % vs 95.5 % (CNN-LSTM), 92.3 % (RF)                            | seen-family protocol: ensemble 95.74%, RF 99.42%                                                                                                             | synthetic task is easy for tree models; ordering is not the point                                 |
| Zero-day families                              | novelty detection 99.8 % (Table 10)                                  | unseen: timing_probe 100.0%, spectral_dga 63.0% (ensemble); RF 100.0% / 100.0%                                                                               | components matter on unseen structure; see D5                                                     |
| Throughput 15.3 M qps (Table 8)                | 15.3 M qps aggregate                                                 | 3,694 qps per core here -> 4,141 instances for 15.3 M qps                                                                                                    | persistence + spectral extraction dominates in Python                                             |
| Ablation (not performed in thesis, Sec 7.3.1)  | none reported                                                        | unseen-family TPR by subset: CMA 82.6%; TMN 50.5%; CMA+TMN 72.7%; SGI 84.7%; CMA+SGI 89.0%; TMN+SGI 53.1%; CMA+TMN+SGI 81.5%                                 | full factorial in D5                                                                              |
| Catastrophic forgetting (Table 10)             | 8.3 % -> 0 %                                                         | Phase 3 forgetting by lambda: 0.0: 0.0 ± 0.0 %; 10.0: 0.0 ± 0.0 %; 100.0: 0.0 ± 0.0 %; 1000.0: 0.0 ± 0.0 %                                                   | no forgetting appears at lambda=0 in this setup, so a benefit of the penalty cannot be shown here |
| Multi-hop (50+ hops, Table 9/Sec 3.15)         | detected over 50+ hops vs 35 for baselines                           | longest loop: p=0.95,T=1.0: 0 %; p=0.95,T=3.0: 98 %; p=0.99,T=1.0: 35 %; p=0.99,T=3.0: 100 %                                                                 | depends on edge observation and memory depth                                                      |
| Spectral accuracy (Table 12: 98.9 % vs 65.4 %) | 98.9 % vs 65.4 %                                                     | spectral_dga: spectral state 81.5 ± 5.8 %, flow state 99.4 ± 0.4 %                                                                                           | not reproduced: the flow metadata here already contains a rate-spectrum feature (lowband_power)   |
| Pi_2 morph 3.8-9.5 ms (Table 9)                | 3.8-9.5 ms                                                           | McEliece pk transfer alone: 100 Mbit/s, RTT 5 ms: 88.87 ms; 1000 Mbit/s, RTT 1 ms: 9.39 ms; 1000 Mbit/s, RTT 5 ms: 13.39 ms; 10000 Mbit/s, RTT 1 ms: 1.84 ms | needs pre-provisioned key or >= ~1 Gbit/s                                                         |
| ML-KEM-768/1024 sizes and correctness          | Table 5 uses FIPS 203 sets                                           | ML-KEM-512 sizes match: True, round trips 200/200; ML-KEM-768 sizes match: True, round trips 200/200; ML-KEM-1024 sizes match: True, round trips 200/200     | reference implementation, not KAT validated                                                       |
| CCE structural causal inference (Sec 3.8)      | 5.4x lower detection time with CMA+SGI; CCE reduces false adaptation | protocol downgrade: naive 0.596 vs do 0.183; AI mimicry: naive 0.366 vs do 0.126; timing probe on key setup: naive 0.166 vs do 0.049                         | confounding bias is large in these assumed SCMs                                                   |
| Loihi 2 / FPGA latency and energy              | 78 us, 8.9 ms morph, sub-2 ms crypto latency                         | not reproducible without the hardware                                                                                                                        | CPU numbers here are baselines only                                                               |
| Quantum-adversary simulations (Sec 3.18)       | limited information gain                                             | not reproducible: no quantum simulator in this artifact                                                                                                      | the thesis itself says no unconditional PQ security is claimed                                    |


## 2. Detection experiments (D1-D6)


### D1a Detectors trained on seen families (* = zero-day)

| detector                      | FPR                 | gan_flood   | *timing_probe   | downgrade   | tunnel   | *spectral_dga   | accuracy   |   mean AUC |
|:------------------------------|:--------------------|:------------|:----------------|:------------|:---------|:----------------|:-----------|-----------:|
| Rule-based                    | 1.56% [1.14%,2.13%] | 0.2%        | 92.4%           | 42.6%       | 100.0%   | 0.6%            | 72.80%     |      0.803 |
| Random Forest (sklearn)       | 1.16% [0.81%,1.66%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 100.0%          | 99.42%     |      1     |
| MLP (sklearn)                 | 1.32% [0.94%,1.85%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 0.0%            | 89.34%     |      0.803 |
| CMA alone                     | 0.68% [0.42%,1.09%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 65.2%           | 96.18%     |      0.978 |
| TMN alone                     | 1.28% [0.91%,1.80%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 1.0%            | 89.46%     |      0.928 |
| SGI alone                     | 0.64% [0.39%,1.04%] | 100.0%      | 100.0%          | 1.4%        | 93.4%    | 69.4%           | 86.10%     |      0.903 |
| MIRAGE ensemble (CMA+TMN+SGI) | 1.12% [0.78%,1.61%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 63.0%           | 95.74%     |      0.991 |


### D1b Detectors trained on all families

| detector                      | FPR                 | gan_flood   | timing_probe   | downgrade   | tunnel   | spectral_dga   | accuracy   |   mean AUC |
|:------------------------------|:--------------------|:------------|:---------------|:------------|:---------|:---------------|:-----------|-----------:|
| Rule-based                    | 1.56% [1.14%,2.13%] | 0.2%        | 92.4%          | 42.6%       | 100.0%   | 0.6%           | 72.80%     |      0.803 |
| Random Forest (sklearn)       | 1.16% [0.81%,1.66%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.42%     |      1     |
| MLP (sklearn)                 | 0.72% [0.46%,1.14%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.64%     |      1     |
| CMA alone                     | 0.88% [0.58%,1.33%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.56%     |      1     |
| TMN alone                     | 1.08% [0.74%,1.57%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 99.8%          | 99.44%     |      1     |
| SGI alone                     | 0.56% [0.33%,0.94%] | 100.0%      | 100.0%         | 1.4%        | 93.4%    | 60.4%          | 85.24%     |      0.902 |
| MIRAGE ensemble (CMA+TMN+SGI) | 0.76% [0.49%,1.18%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.62%     |      1     |


### D1c Scoring cost (CPU, one core)

| scorer (given precomputed inputs)          |   us/window |
|:-------------------------------------------|------------:|
| Rule-based                                 |         0   |
| Random Forest (200 trees)                  |        51.1 |
| MLP                                        |         0.8 |
| CMA policy forward                         |         0.2 |
| TMN (diagram attention + LSTM, 3-window)   |       116.7 |
| SGI spectral classifier                    |         0.1 |
| metadata features (20) from a window       |       357.6 |
| persistence + spectral state from a window |     16849.3 |


### D1d Implied instances for 15.3 M qps

| quantity                                               | value                      |
|:-------------------------------------------------------|:---------------------------|
| ensemble cost per 64-query window (us)                 | 17324                      |
| single-core queries/s (this implementation)            | 3,694                      |
| instances needed for 15.3M qps (Table 8) at this speed | 4,141                      |
| CPU per instance bound in Sec 3.4.2                    | < 5 % of resolver capacity |


### D1e CTAI (Eq. 29, latency term omitted)

| detector                      |   accuracy |    FPR |   CTAI (alpha=1,1,0 ; latency omitted) |
|:------------------------------|-----------:|-------:|---------------------------------------:|
| Rule-based                    |     0.728  | 0.0156 |                                 0.7124 |
| Random Forest (sklearn)       |     0.9942 | 0.0116 |                                 0.9826 |
| MLP (sklearn)                 |     0.9964 | 0.0072 |                                 0.9892 |
| CMA alone                     |     0.9956 | 0.0088 |                                 0.9868 |
| TMN alone                     |     0.9944 | 0.0108 |                                 0.9836 |
| SGI alone                     |     0.8524 | 0.0056 |                                 0.8468 |
| MIRAGE ensemble (CMA+TMN+SGI) |     0.9962 | 0.0076 |                                 0.9886 |


### D5 Full factorial ablation

| components   | FPR   | TPR seen families   | TPR unseen (zero-day)   |   AUC unseen |
|:-------------|:------|:--------------------|:------------------------|-------------:|
| CMA          | 0.68% | 100.0%              | 82.6%                   |        0.946 |
| TMN          | 1.28% | 100.0%              | 50.5%                   |        0.819 |
| CMA+TMN      | 1.20% | 100.0%              | 72.7%                   |        0.948 |
| SGI          | 0.64% | 64.9%               | 84.7%                   |        0.991 |
| CMA+SGI      | 0.64% | 100.0%              | 89.0%                   |        0.981 |
| TMN+SGI      | 1.36% | 100.0%              | 53.1%                   |        0.886 |
| CMA+TMN+SGI  | 1.12% | 100.0%              | 81.5%                   |        0.977 |


### D2 CMA curriculum and Fisher penalty

|   lambda (Fisher) | phase                         |   F1 (%) |   AUC | novelty zero-shot (%)   |   novelty after adaptation (%) | forgetting (%)   |   FPR (%) |
|------------------:|:------------------------------|---------:|------:|:------------------------|-------------------------------:|:-----------------|----------:|
|                 0 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 2 (dynamic threats)     |     66.7 | 1     | 50.0                    |                           50   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 3 (live)                |    100   | 1     | 0.0                     |                          100   | 0.0 ± 0.0        |         0 |
|                10 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|                10 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|                10 | Phase 2 (dynamic threats)     |     44.4 | 0.728 | 50.0                    |                           33.3 | 33.3 ± 65.3      |         0 |
|                10 | Phase 3 (live)                |     99.8 | 1     | 0.3                     |                           99.2 | 0.0 ± 0.0        |         0 |
|               100 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|               100 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|               100 | Phase 2 (dynamic threats)     |     44.4 | 0.862 | 50.0                    |                           33.3 | 33.3 ± 65.3      |         0 |
|               100 | Phase 3 (live)                |     96.5 | 1     | 3.0                     |                           78   | 0.0 ± 0.0        |         0 |
|              1000 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 2 (dynamic threats)     |     66.7 | 0.727 | 50.0                    |                           50   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 3 (live)                |     98.9 | 1     | 0.2                     |                           94   | 0.0 ± 0.0        |         0 |


### D3a TMN relay-loop detection

|   hops L |   P(edge observed) |   memory windows T |   detection |   bounded-RF baseline (R=35), full observation |
|---------:|-------------------:|-------------------:|------------:|-----------------------------------------------:|
|       10 |               0.95 |                  1 |       0.45  |                                              1 |
|       10 |               0.95 |                  3 |       1     |                                              1 |
|       10 |               0.99 |                  1 |       0.9   |                                              1 |
|       10 |               0.99 |                  3 |       1     |                                              1 |
|       30 |               0.95 |                  1 |       0.25  |                                              1 |
|       30 |               0.95 |                  3 |       1     |                                              1 |
|       30 |               0.99 |                  1 |       0.65  |                                              1 |
|       30 |               0.99 |                  3 |       1     |                                              1 |
|       50 |               0.95 |                  1 |       0.075 |                                              0 |
|       50 |               0.95 |                  3 |       1     |                                              0 |
|       50 |               0.99 |                  1 |       0.65  |                                              0 |
|       50 |               0.99 |                  3 |       1     |                                              0 |
|       80 |               0.95 |                  1 |       0     |                                              0 |
|       80 |               0.95 |                  3 |       0.975 |                                              0 |
|       80 |               0.99 |                  1 |       0.35  |                                              0 |
|       80 |               0.99 |                  3 |       1     |                                              0 |


### D3b Order dependence

| feature                                                    |   mean change |
|:-----------------------------------------------------------|--------------:|
| persistence diagram of the point cloud (relabelled points) |          0    |
| lag-1 autocorrelation (packet order shuffled)              |          0.39 |


### D4 DQN defender, spectral vs flow state

| scenario                                    | state                       | accuracy    |   TPR |   FPR |   mean reward/step |
|:--------------------------------------------|:----------------------------|:------------|------:|------:|-------------------:|
| spectral_dga [target (structural)]          | spectral (k=16 eigenvalues) | 81.5 ± 5.8  |  98.3 |  21.9 |              0.029 |
| spectral_dga [target (structural)]          | flow metadata (20 features) | 99.4 ± 0.4  | 100   |   0.7 |              0.115 |
| gan_flood [negative control (flow-visible)] | spectral (k=16 eigenvalues) | 100.0 ± 0.0 | 100   |   0   |              0.117 |
| gan_flood [negative control (flow-visible)] | flow metadata (20 features) | 96.6 ± 1.6  | 100   |   4   |              0.045 |


### D6 Levy jump test

|   jump rate/step |   jump scale (x sigma) |   mean 1-BV/RV |    sd |   power @1% FPR |
|-----------------:|-----------------------:|---------------:|------:|----------------:|
|            0     |                      3 |          0.01  | 0.015 |      nan        |
|            0.005 |                      3 |          0.02  | 0.023 |        0.216667 |
|            0.005 |                      6 |          0.088 | 0.077 |        0.633333 |
|            0.01  |                      3 |          0.036 | 0.03  |        0.366667 |
|            0.01  |                      6 |          0.155 | 0.086 |        0.966667 |
|            0.02  |                      3 |          0.073 | 0.038 |        0.65     |
|            0.02  |                      6 |          0.273 | 0.092 |        1        |

![D2/D4 curves](d2_d4_curves.png)

![D3 TMN](d3_tmn_hops.png)


## 3. Cryptographic agility and causal reasoning (C1-C7)


### C1 ML-KEM reference

| parameter set   | ek/dk/ct bytes   | matches FIPS 203 sizes   | round trips ok (200)   | implicit rejection (100 corrupted ct)   | rejection deterministic   |   keygen ms |   encaps ms |   decaps ms |
|:----------------|:-----------------|:-------------------------|:-----------------------|:----------------------------------------|:--------------------------|------------:|------------:|------------:|
| ML-KEM-512      | 800/1632/768     | True                     | 200/200                | 100/100                                 | True                      |         2   |         2.5 |         3.2 |
| ML-KEM-768      | 1184/2400/1088   | True                     | 200/200                | 100/100                                 | True                      |         2.8 |         3.5 |         4.5 |
| ML-KEM-1024     | 1568/3168/1568   | True                     | 200/200                | 100/100                                 | True                      |         4.1 |         4.9 |         6.1 |


### C2a Combiner avalanche

| perturbation          |   mean bit flips of 256 |   sd |   min |   max | ideal (binomial)   |
|:----------------------|------------------------:|-----:|------:|------:|:-------------------|
| flip 1 bit of ss1     |                   128.2 |  8.2 |   101 |   153 | 128.0 +- 8.0       |
| flip 1 bit of ss2     |                   128   |  8.2 |   102 |   155 | 128.0 +- 8.0       |
| change context string |                   127.9 |  8   |   104 |   155 | 128.0 +- 8.0       |


### C2b One component compromised

| scenario                                      |   keys |   monobit z |   runs z |   byte chi-square p |
|:----------------------------------------------|-------:|------------:|---------:|--------------------:|
| ss1 fully known to the adversary, ss2 uniform |   4000 |        0.67 |     0.12 |               0.921 |


### C3a Compute and wire bytes per level

| level   | KEMs                          |   NIST category |   keygen ms |   encaps ms |   decaps ms |   KDF+AEAD ms | measured CPU total ms             |   c->s bytes |   s->c bytes |
|:--------|:------------------------------|----------------:|------------:|------------:|------------:|--------------:|:----------------------------------|-------------:|-------------:|
| Pi_0    | ML-KEM-768 + X25519           |               3 |         2.9 |         3.7 |         4.6 |         0.018 | 11.2                              |         1216 |         1164 |
| Pi_1    | ML-KEM-1024 + X25519          |               5 |         4.2 |         5   |         6.2 |         0.022 | 15.4                              |         1600 |         1644 |
| Pi_2    | ML-KEM-1024 + mceliece6688128 |               5 |         4.1 |         5   |         6.1 |         0.035 | 15.2 (McEliece part not measured) |      1046560 |         1820 |


### C3b Morph time vs 10 ms target

| level                      | link                   |   wire bytes |   transfer+RTT ms |   measured CPU ms (python ML-KEM) |   total ms | <= 10 ms   |   left for compute within 10 ms |
|:---------------------------|:-----------------------|-------------:|------------------:|----------------------------------:|-----------:|:-----------|--------------------------------:|
| Pi_0                       | 100 Mbit/s, RTT 5 ms   |         2380 |              5.19 |                              11.2 |       16.4 | False      |                            4.81 |
| Pi_0                       | 1000 Mbit/s, RTT 1 ms  |         2380 |              1.02 |                              11.2 |       12.2 | False      |                            8.98 |
| Pi_0                       | 1000 Mbit/s, RTT 5 ms  |         2380 |              5.02 |                              11.2 |       16.2 | False      |                            4.98 |
| Pi_0                       | 10000 Mbit/s, RTT 1 ms |         2380 |              1    |                              11.2 |       12.2 | False      |                            9    |
| Pi_1                       | 100 Mbit/s, RTT 5 ms   |         3244 |              5.26 |                              15.4 |       20.7 | False      |                            4.74 |
| Pi_1                       | 1000 Mbit/s, RTT 1 ms  |         3244 |              1.03 |                              15.4 |       16.5 | False      |                            8.97 |
| Pi_1                       | 1000 Mbit/s, RTT 5 ms  |         3244 |              5.03 |                              15.4 |       20.5 | False      |                            4.97 |
| Pi_1                       | 10000 Mbit/s, RTT 1 ms |         3244 |              1    |                              15.4 |       16.4 | False      |                            9    |
| Pi_2                       | 100 Mbit/s, RTT 5 ms   |      1048380 |             88.87 |                              15.2 |      104.1 | False      |                          -78.87 |
| Pi_2                       | 1000 Mbit/s, RTT 1 ms  |      1048380 |              9.39 |                              15.2 |       24.6 | False      |                            0.61 |
| Pi_2                       | 1000 Mbit/s, RTT 5 ms  |      1048380 |             13.39 |                              15.2 |       28.6 | False      |                           -3.39 |
| Pi_2                       | 10000 Mbit/s, RTT 1 ms |      1048380 |              1.84 |                              15.2 |       17   | False      |                            8.16 |
| Pi_2 (pk2 pre-provisioned) | 100 Mbit/s, RTT 5 ms   |         3388 |              5.27 |                              15.2 |       20.5 | False      |                            4.73 |
| Pi_2 (pk2 pre-provisioned) | 1000 Mbit/s, RTT 1 ms  |         3388 |              1.03 |                              15.2 |       16.2 | False      |                            8.97 |
| Pi_2 (pk2 pre-provisioned) | 1000 Mbit/s, RTT 5 ms  |         3388 |              5.03 |                              15.2 |       20.2 | False      |                            4.97 |
| Pi_2 (pk2 pre-provisioned) | 10000 Mbit/s, RTT 1 ms |         3388 |              1    |                              15.2 |       16.2 | False      |                            9    |


### C3c McEliece public key

| quantity                                               |          value |
|:-------------------------------------------------------|---------------:|
| McEliece6688128 public key (bytes)                     |    1.04499e+06 |
| link rate at which this key alone takes 10 ms (Gbit/s) |    0.84        |
| same key over 100 Mbit/s (ms)                          |   84           |
| ML-KEM-1024 pk + ct (bytes)                            | 3136           |


### C4 Threat-level policy

| threat stream                         | thresholds          |   min level (floor Pi_0) | time at Pi_0/Pi_1/Pi_2 (%)   |   level switches |   steps to Pi_2 after onset |
|:--------------------------------------|:--------------------|-------------------------:|:-----------------------------|-----------------:|----------------------------:|
| benign                                | fixed thresholds    |                        0 | 98/2/0                       |               16 |                         nan |
| benign                                | adaptive thresholds |                        0 | 99/1/0                       |                8 |                         nan |
| attack burst                          | fixed thresholds    |                        0 | 82/5/13                      |               52 |                           0 |
| attack burst                          | adaptive thresholds |                        0 | 83/12/5                      |               38 |                           0 |
| evasive (rho held just under gamma_1) | fixed thresholds    |                        0 | 84/16/0                      |              153 |                         nan |
| evasive (rho held just under gamma_1) | adaptive thresholds |                        0 | 100/0/0                      |                3 |                         nan |
| oscillating around gamma_1            | fixed thresholds    |                        0 | 50/50/0                      |               64 |                         nan |
| oscillating around gamma_1            | adaptive thresholds |                        0 | 69/31/0                      |               64 |                         nan |
| saturated (rho = 1)                   | fixed thresholds    |                        2 | 0/0/100                      |                0 |                         nan |
| saturated (rho = 1)                   | adaptive thresholds |                        2 | 0/0/100                      |                0 |                         nan |


### C5a Causal engine

| scenario                                 |   P(Y|X=1) observational |   P(Y|do(X=1)) Eq.15 |   Eq.15 by adjustment |   confounding bias |   P(Y_x'=0 | X=1,Y=1) counterfactual |   baseline risk | chosen action P*                    |   risk after P* | risk reduction   |
|:-----------------------------------------|-------------------------:|---------------------:|----------------------:|-------------------:|-------------------------------------:|----------------:|:------------------------------------|----------------:|:-----------------|
| protocol downgrade (TLS1.3->1.2 via ECS) |                    0.596 |                0.183 |                 0.182 |              0.414 |                                0.1   |           0.154 | disable TLS1.2 fallback             |           0.03  | 81%              |
| AI mimicry (rule-evasion)                |                    0.366 |                0.126 |                 0.126 |              0.24  |                                0.079 |           0.09  | enforce 256-bit nonce + new session |           0.025 | 72%              |
| timing probe on key setup                |                    0.166 |                0.049 |                 0.049 |              0.117 |                                0.048 |           0.039 | escalate shard to Pi_2              |           0.008 | 80%              |


### C5b Confounding sweep

|   P(X=1|intent=1) |   P(Y|X=1) |   P(Y|do(X=1)) | naive overestimate   |
|------------------:|-----------:|---------------:|:---------------------|
|              0.05 |      0.182 |          0.183 | -0%                  |
|              0.25 |      0.441 |          0.183 | +142%                |
|              0.5  |      0.541 |          0.183 | +196%                |
|              0.75 |      0.585 |          0.183 | +221%                |
|              0.95 |      0.606 |          0.183 | +232%                |


### C5c Hardening actions

| scenario                                 | action                              |   P(compromise) |   expected reward | chosen   |
|:-----------------------------------------|:------------------------------------|----------------:|------------------:|:---------|
| protocol downgrade (TLS1.3->1.2 via ECS) | disable TLS1.2 fallback             |          0.0296 |             -3.36 | True     |
| protocol downgrade (TLS1.3->1.2 via ECS) | strip ECS from upstream             |          0.0513 |             -5.33 | False    |
| protocol downgrade (TLS1.3->1.2 via ECS) | none                                |          0.1536 |            -15.36 | False    |
| AI mimicry (rule-evasion)                | enforce 256-bit nonce + new session |          0.0248 |             -3.08 | True     |
| AI mimicry (rule-evasion)                | tighten entropy rules               |          0.0464 |             -4.74 | False    |
| AI mimicry (rule-evasion)                | none                                |          0.0895 |             -8.95 | False    |
| timing probe on key setup                | escalate shard to Pi_2              |          0.0075 |             -1.75 | True     |
| timing probe on key setup                | add lattice noise                   |          0.0157 |             -1.87 | False    |
| timing probe on key setup                | none                                |          0.0386 |             -3.86 | False    |


### C6a SE(3) flow checks

| check                                                       | result                |
|:------------------------------------------------------------|:----------------------|
| group closure: ||R^T R - I||_F after 4000 steps             | 1.77e-14              |
| monobit z over 1,024,000 key bits                           | +0.80                 |
| runs test z                                                 | +0.57                 |
| byte chi-square p-value                                     | 0.528                 |
| mean |corr| of successive keys (32 bit positions)           | 0.0128                |
| avalanche: bit flips for a 1e-09 change in rho (100 trials) | 1.2 of 256 (sd 12.0)  |
| avalanche: bit flips for a 1e-06 change in rho (100 trials) | 128.0 of 256 (sd 7.3) |
| avalanche: bit flips for a 0.001 change in rho (100 trials) | 127.3 of 256 (sd 7.6) |
| minimum pairwise distance between visited states            | 1.040e+00             |
| cost per re-randomisation step (expm 4x4 + KDF), us         | 33                    |


### C6b SE(3) predictability

| diffusion schedule           |   next-state prediction error (Frobenius, last 100 steps) |
|:-----------------------------|----------------------------------------------------------:|
| sigma = 0.01 (floor)         |                                                    0.0281 |
| sigma = 0.05                 |                                                    0.1407 |
| sigma = 0.2                  |                                                    0.5603 |
| sigma = 0.6 (cap)            |                                                    1.6227 |
| sigma = 0.2/(1+t) (annealed) |                                                    0.0016 |


### C7 Scope of Eq. 12

| level   | components                    |   NIST category (thesis) | Eq. 12 statement                     | what it covers                                                                      | does not cover                                                                              |
|:--------|:------------------------------|-------------------------:|:-------------------------------------|:------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| Pi_0    | ML-KEM-768 + X25519           |                        3 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |
| Pi_1    | ML-KEM-1024 + X25519          |                        5 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |
| Pi_2    | ML-KEM-1024 + mceliece6688128 |                        5 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |


## 4. System-level attack scenarios (S1-S5)


### S1 Scenario catalogue

| attack (thesis name)          | simulated family   | behaviour                                              | source        | module expected to carry it   |
|:------------------------------|:-------------------|:-------------------------------------------------------|:--------------|:------------------------------|
| AI-powered adversarial flood  | gan_flood          | generated pseudo-words, unique names, 10-50 ms spacing | Table 6 row 1 | CMA, SGI                      |
| Quantum-assisted timing probe | timing_probe       | regular, rapid handshakes with near-constant timing    | Table 6 row 2 | CMA, MCS                      |
| Protocol downgrade            | downgrade          | TLS 1.2 fallback, ECS manipulation, varying extensions | Table 6 row 3 | CMA, CCE, MCS                 |
| Multi-phase tunnelling        | tunnel             | slow, long high-entropy labels, TXT-heavy              | Table 6 row 4 | TMN                           |
| Structural / spectral DGA     | spectral_dga       | dictionary names, slow cyclic rate modulation          | Table 6 row 5 | SGI                           |


### S2 End-to-end pipeline per attack

| attack       |   windows to Pi_1+ after onset |   windows to Pi_2 after onset | runs reaching Pi_1+   | runs reaching Pi_2   | false escalations before onset   |   mean level after onset |   morph events/run |   morph bytes/run (McEliece pk sent) |   morph bytes/run (pk pre-provisioned) | causal hardening (CCE)                                  |
|:-------------|-------------------------------:|------------------------------:|:----------------------|:---------------------|:---------------------------------|-------------------------:|-------------------:|-------------------------------------:|---------------------------------------:|:--------------------------------------------------------|
| gan_flood    |                            0   |                           0   | 6/6                   | 6/6                  | 2.5%                             |                     2    |                4   |                            1,231,005 |                                 11,757 | enforce 256-bit nonce + new session (risk 9.0% -> 2.5%) |
| timing_probe |                            0   |                           0   | 6/6                   | 6/6                  | 3.9%                             |                     2    |                5.2 |                            1,234,214 |                                 14,929 | escalate shard to Pi_2 (risk 3.9% -> 0.8%)              |
| downgrade    |                            0   |                           0   | 6/6                   | 6/6                  | 3.3%                             |                     2    |                4.3 |                            1,057,753 |                                 12,655 | disable TLS1.2 fallback (risk 15.4% -> 3.0%)            |
| tunnel       |                            0   |                           0   | 6/6                   | 6/6                  | 4.2%                             |                     2    |                5.8 |                            1,062,043 |                                 16,897 | no CCE scenario defined                                 |
| spectral_dga |                            0.8 |                           2.3 | 6/6                   | 6/6                  | 5.8%                             |                     0.73 |               43.3 |                            9,009,397 |                                125,851 | no CCE scenario defined                                 |

![pipeline timelines](s2_pipeline.png)

S3 is a queueing model: resolver capacity 22,000 qps, benign load 5,000 qps, 0.5 s timeout, 0.2 s detection delay, filter efficiency taken from the ensemble's measured TPR/FPR; the capacity and delay values are assumptions.


### S3 Resilience under volumetric load (model)

|   attack rate (qps) |   benign rate (qps) | benign queries lost: fixed resolver   | benign queries lost: detect+filter   | benign queries lost: detect+filter+2x capacity   |
|--------------------:|--------------------:|:--------------------------------------|:-------------------------------------|:-------------------------------------------------|
|                   0 |                5000 | 0.0%                                  | 0.0%                                 | 0.0%                                             |
|                5000 |                5000 | 0.0%                                  | 0.7%                                 | 0.6%                                             |
|               10000 |                5000 | 0.0%                                  | 0.6%                                 | 0.7%                                             |
|               20000 |                5000 | 0.0%                                  | 0.7%                                 | 0.7%                                             |
|               30000 |                5000 | 15.8%                                 | 0.7%                                 | 0.6%                                             |

![resilience](s3_resilience.png)


### S4 Evasion strength sweep

|   evasion strength s | Random Forest TPR   | MLP TPR   | MIRAGE ensemble TPR   |
|---------------------:|:--------------------|:----------|:----------------------|
|                 0    | 100.0%              | 80.0%     | 92.3%                 |
|                 0.25 | 95.3%               | 83.3%     | 84.0%                 |
|                 0.5  | 95.3%               | 84.7%     | 83.3%                 |
|                 0.75 | 87.3%               | 81.7%     | 86.0%                 |
|                 1    | 42.3%               | 8.0%      | 26.7%                 |

![evasion](s4_evasion.png)


### S5 Hyper-parameter spread over 20 random configurations

| model         |   configs | F1 mean   |    sd | min    | max     |
|:--------------|----------:|:----------|------:|:-------|:--------|
| CMA (ES)      |        20 | 94.00%    | 22.57 | 0.00%  | 100.00% |
| Random Forest |        20 | 99.97%    |  0.1  | 99.63% | 100.00% |
| MLP           |        20 | 94.00%    | 22.57 | 0.00%  | 100.00% |


## 5. Arithmetic audit of the Chapter 3 tables

| item                                 | stated in Chapter 3                                        | implied / recomputed                                                       | reading                                                                               |
|:-------------------------------------|:-----------------------------------------------------------|:---------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Table 8 latency improvement          | 62.8 % vs CNN-LSTM                                         | 62.9 %                                                                     | consistent                                                                            |
| Table 8 throughput improvement       | 75.9 % vs CNN-LSTM                                         | 75.9 %                                                                     | consistent                                                                            |
| Table 8 FPR reduction vs CNN-LSTM    | 99.5 %                                                     | 99.47 %                                                                    | consistent                                                                            |
| Table 8 accuracy gain vs CNN-LSTM    | 4.48 pp                                                    | 4.48 pp                                                                    | consistent                                                                            |
| Table 9 latency speed-up             | 6.9x (135-160 us vs 18-28 us)                              | 4.8x to 8.9x (midpoints 6.4x)                                              | 6.9x lies inside the range, not derivable from the endpoints                          |
| Table 12 detection-time factor       | 5.4x (120-150 ms vs 22-35 ms)                              | 3.4x to 6.8x (midpoints 4.7x)                                              | 5.4x lies inside the range                                                            |
| Table 12 FP-rate factor              | 25.7x (1.8 % vs 0.07 %)                                    | 25.7x                                                                      | consistent                                                                            |
| Table 12 topological recall factor   | 1.37x                                                      | 1.37x                                                                      | consistent                                                                            |
| Table 12 spectral accuracy factor    | 1.51x                                                      | 1.51x                                                                      | consistent                                                                            |
| Morph time range                     | 3.8-9.5 ms (Tables 9, 12; Sec 3.15.1), every value < 10 ms | text after Table 12: 'took 4.2-12.1 ms to reconfigure'                     | contradiction: 12.1 ms exceeds the 10 ms target and the stated range                  |
| Topological recall of TMN            | 99.1 % (Table 12), 99.4 % (Table 9), 99.93 % (Sec 3.15)    | three values for one quantity                                              | state which evaluation each refers to                                                 |
| False-positive rate                  | 0.0008 % (Table 8), 0.05 % (Table 9), 0.07 % (Table 12)    | different baselines per table (as the notes say)                           | fine if kept apart; 0.0008 % needs a very large benign sample                         |
| Sample size for FPR 0.0008 %         | CI +-0.0001 pp, no sample counts (Sec 3.16)                | certifying 0 FP at 8e-6 needs >= 374,466 benign windows (95 %)             | report the benign count                                                               |
| Throughput vs latency (Eq. 31)       | 15.3 M qps aggregate, 78 us per query                      | 1,193 concurrent instances needed (15.3e6 x 78e-6)                         | check against the < 5 % CPU, 16 GB per instance bound of Sec 3.18                     |
| Eq. 31 dimension                     | T_total = (sum_i lambda_i)^-1 * C_parallel                 | summing per-class times is not a rate                                      | use C_parallel / mean per-query time                                                  |
| Detection time vs scoring latency    | 22-35 ms end-to-end (Table 12) vs 78 us scoring (Table 8)  | ratio ~ 280-450x                                                           | documented in the Table 12 note                                                       |
| McEliece public key in a 10 ms morph | Pi_2 morph 3.8-9.5 ms                                      | mceliece6688128 pk = 1,044,992 B -> 0.84 Gbit/s needed to move it in 10 ms | feasible only if the key is pre-provisioned or the link is >= ~1 Gbit/s with tiny RTT |
| Figure 4 plateaus                    | all modules start at 0.26 and reach 0.82                   | identical start and end values for four curves                             | confirm these are separate measurements                                               |
| Hyper-parameter sensitivity          | 20 configurations, 88-89 % vs 83-89 %                      | a 1-point spread over 20 configs                                           | report sd and the sampled ranges                                                      |


## 6. Environment

Python 3.12.3, numpy 2.5.4, Linux-6.18.44-fc-v653-x86_64-with-glibc2.39; system suite wall time 4s.
