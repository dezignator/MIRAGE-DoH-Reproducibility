# MIRAGE-DoH cryptographic agility, policy and causal experiments (v2)

Real: X25519, ChaCha20-Poly1305, SHAKE/SHA3. Educational: pure-Python ML-KEM (FIPS 203 structure, not KAT validated). Not implemented: Classic McEliece (size model only). Network times are modelled from link parameters.

### C1 ML-KEM reference implementation

| parameter set   | ek/dk/ct bytes   | matches FIPS 203 sizes   | round trips ok (200)   | implicit rejection (100 corrupted ct)   | rejection deterministic   |   keygen ms |   encaps ms |   decaps ms |
|:----------------|:-----------------|:-------------------------|:-----------------------|:----------------------------------------|:--------------------------|------------:|------------:|------------:|
| ML-KEM-512      | 800/1632/768     | True                     | 200/200                | 100/100                                 | True                      |         2   |         2.5 |         3.2 |
| ML-KEM-768      | 1184/2400/1088   | True                     | 200/200                | 100/100                                 | True                      |         2.8 |         3.5 |         4.5 |
| ML-KEM-1024     | 1568/3168/1568   | True                     | 200/200                | 100/100                                 | True                      |         4.1 |         4.9 |         6.1 |

### C2a Hybrid combiner avalanche (Eq. 11)

| perturbation          |   mean bit flips of 256 |   sd |   min |   max | ideal (binomial)   |
|:----------------------|------------------------:|-----:|------:|------:|:-------------------|
| flip 1 bit of ss1     |                   128.2 |  8.2 |   101 |   153 | 128.0 +- 8.0       |
| flip 1 bit of ss2     |                   128   |  8.2 |   102 |   155 | 128.0 +- 8.0       |
| change context string |                   127.9 |  8   |   104 |   155 | 128.0 +- 8.0       |

### C2b Combiner output when one KEM is fully compromised (AEAD tamper test: rejected)

| scenario                                      |   keys |   monobit z |   runs z |   byte chi-square p |
|:----------------------------------------------|-------:|------------:|---------:|--------------------:|
| ss1 fully known to the adversary, ss2 uniform |   4000 |        0.67 |     0.12 |               0.921 |

### C3a Per-level compute and wire bytes (measured CPU, modelled McEliece sizes)

| level   | KEMs                          |   NIST category |   keygen ms |   encaps ms |   decaps ms |   KDF+AEAD ms | measured CPU total ms             |   c->s bytes |   s->c bytes |
|:--------|:------------------------------|----------------:|------------:|------------:|------------:|--------------:|:----------------------------------|-------------:|-------------:|
| Pi_0    | ML-KEM-768 + X25519           |               3 |         2.9 |         3.7 |         4.6 |         0.018 | 11.2                              |         1216 |         1164 |
| Pi_1    | ML-KEM-1024 + X25519          |               5 |         4.2 |         5   |         6.2 |         0.022 | 15.4                              |         1600 |         1644 |
| Pi_2    | ML-KEM-1024 + mceliece6688128 |               5 |         4.1 |         5   |         6.1 |         0.035 | 15.2 (McEliece part not measured) |      1046560 |         1820 |

### C3b Morph time against the 10 ms target, by link

| level                      | link                   |   wire bytes |   transfer+RTT ms |   measured CPU ms (python ML-KEM) |   total ms | <= 10 ms   |   left for compute within 10 ms |
|:---------------------------|:-----------------------|-------------:|------------------:|----------------------------------:|-----------:|:-----------|--------------------------------:|
| Pi_0                       | 100 Mbit/s, RTT 5 ms   |         2380 |              5.19 |                              11.2 |       16.4 | False      |                            4.81 |
| Pi_0                       | 1000 Mbit/s, RTT 1 ms  |         2380 |              1.02 |                              11.2 |       12.2 | False      |                            8.98 |
| Pi_0                       | 1000 Mbit/s, RTT 5 ms  |         2380 |              5.02 |                              11.2 |       16.2 | False      |                            4.98 |
| Pi_0                       | 10000 Mbit/s, RTT 1 ms |         2380 |              1    |                              11.2 |       12.2 | False      |                            9    |
| Pi_1                       | 100 Mbit/s, RTT 5 ms   |         3244 |              5.26 |                              15.4 |       20.7 | False      |                            4.74 |
| Pi_1                       | 1000 Mbit/s, RTT 1 ms  |         3244 |              1.03 |                              15.4 |       16.5 | False      |                            8.97 |
| Pi_1                       | 1000 Mbit/s, RTT 5 ms  |         3244 |              5.03 |                              15.4 |       20.5 | False      |                            4.97 |
| Pi_1                       | 10000 Mbit/s, RTT 1 ms |         3244 |              1    |                              15.4 |       16.4 | False      |                            9    |
| Pi_2                       | 100 Mbit/s, RTT 5 ms   |      1048380 |             88.87 |                              15.2 |      104.1 | False      |                          -78.87 |
| Pi_2                       | 1000 Mbit/s, RTT 1 ms  |      1048380 |              9.39 |                              15.2 |       24.6 | False      |                            0.61 |
| Pi_2                       | 1000 Mbit/s, RTT 5 ms  |      1048380 |             13.39 |                              15.2 |       28.6 | False      |                           -3.39 |
| Pi_2                       | 10000 Mbit/s, RTT 1 ms |      1048380 |              1.84 |                              15.2 |       17   | False      |                            8.16 |
| Pi_2 (pk2 pre-provisioned) | 100 Mbit/s, RTT 5 ms   |         3388 |              5.27 |                              15.2 |       20.5 | False      |                            4.73 |
| Pi_2 (pk2 pre-provisioned) | 1000 Mbit/s, RTT 1 ms  |         3388 |              1.03 |                              15.2 |       16.2 | False      |                            8.97 |
| Pi_2 (pk2 pre-provisioned) | 1000 Mbit/s, RTT 5 ms  |         3388 |              5.03 |                              15.2 |       20.2 | False      |                            4.97 |
| Pi_2 (pk2 pre-provisioned) | 10000 Mbit/s, RTT 1 ms |         3388 |              1    |                              15.2 |       16.2 | False      |                            9    |

### C3c Classic McEliece public-key transfer

| quantity                                               |          value |
|:-------------------------------------------------------|---------------:|
| McEliece6688128 public key (bytes)                     |    1.04499e+06 |
| link rate at which this key alone takes 10 ms (Gbit/s) |    0.84        |
| same key over 100 Mbit/s (ms)                          |   84           |
| ML-KEM-1024 pk + ct (bytes)                            | 3136           |

### C4 Threat-level policy (Eq. 13) under benign, attack, evasive and oscillating threat scores

| threat stream                         | thresholds          |   min level (floor Pi_0) | time at Pi_0/Pi_1/Pi_2 (%)   |   level switches |   steps to Pi_2 after onset |
|:--------------------------------------|:--------------------|-------------------------:|:-----------------------------|-----------------:|----------------------------:|
| benign                                | fixed thresholds    |                        0 | 98/2/0                       |               16 |                         nan |
| benign                                | adaptive thresholds |                        0 | 99/1/0                       |                8 |                         nan |
| attack burst                          | fixed thresholds    |                        0 | 82/5/13                      |               52 |                           0 |
| attack burst                          | adaptive thresholds |                        0 | 83/12/5                      |               38 |                           0 |
| evasive (rho held just under gamma_1) | fixed thresholds    |                        0 | 84/16/0                      |              153 |                         nan |
| evasive (rho held just under gamma_1) | adaptive thresholds |                        0 | 100/0/0                      |                3 |                         nan |
| oscillating around gamma_1            | fixed thresholds    |                        0 | 50/50/0                      |               64 |                         nan |
| oscillating around gamma_1            | adaptive thresholds |                        0 | 69/31/0                      |               64 |                         nan |
| saturated (rho = 1)                   | fixed thresholds    |                        2 | 0/0/100                      |                0 |                         nan |
| saturated (rho = 1)                   | adaptive thresholds |                        2 | 0/0/100                      |                0 |                         nan |

### C5a Causal engine: observational vs interventional vs counterfactual (Eqs. 14-16)

| scenario                                 |   P(Y|X=1) observational |   P(Y|do(X=1)) Eq.15 |   Eq.15 by adjustment |   confounding bias |   P(Y_x'=0 | X=1,Y=1) counterfactual |   baseline risk | chosen action P*                    |   risk after P* | risk reduction   |
|:-----------------------------------------|-------------------------:|---------------------:|----------------------:|-------------------:|-------------------------------------:|----------------:|:------------------------------------|----------------:|:-----------------|
| protocol downgrade (TLS1.3->1.2 via ECS) |                    0.596 |                0.183 |                 0.182 |              0.414 |                                0.1   |           0.154 | disable TLS1.2 fallback             |           0.03  | 81%              |
| AI mimicry (rule-evasion)                |                    0.366 |                0.126 |                 0.126 |              0.24  |                                0.079 |           0.09  | enforce 256-bit nonce + new session |           0.025 | 72%              |
| timing probe on key setup                |                    0.166 |                0.049 |                 0.049 |              0.117 |                                0.048 |           0.039 | escalate shard to Pi_2              |           0.008 | 80%              |

### C5b Bias of the naive estimate vs confounding strength

|   P(X=1|intent=1) |   P(Y|X=1) |   P(Y|do(X=1)) | naive overestimate   |
|------------------:|-----------:|---------------:|:---------------------|
|              0.05 |      0.182 |          0.183 | -0%                  |
|              0.25 |      0.441 |          0.183 | +142%                |
|              0.5  |      0.541 |          0.183 | +196%                |
|              0.75 |      0.585 |          0.183 | +221%                |
|              0.95 |      0.606 |          0.183 | +232%                |

### C5c Hardening actions and expected reward

| scenario                                 | action                              |   P(compromise) |   expected reward | chosen   |
|:-----------------------------------------|:------------------------------------|----------------:|------------------:|:---------|
| protocol downgrade (TLS1.3->1.2 via ECS) | disable TLS1.2 fallback             |          0.0296 |             -3.36 | True     |
| protocol downgrade (TLS1.3->1.2 via ECS) | strip ECS from upstream             |          0.0513 |             -5.33 | False    |
| protocol downgrade (TLS1.3->1.2 via ECS) | none                                |          0.1536 |            -15.36 | False    |
| AI mimicry (rule-evasion)                | enforce 256-bit nonce + new session |          0.0248 |             -3.08 | True     |
| AI mimicry (rule-evasion)                | tighten entropy rules               |          0.0464 |             -4.74 | False    |
| AI mimicry (rule-evasion)                | none                                |          0.0895 |             -8.95 | False    |
| timing probe on key setup                | escalate shard to Pi_2              |          0.0075 |             -1.75 | True     |
| timing probe on key setup                | add lattice noise                   |          0.0157 |             -1.87 | False    |
| timing probe on key setup                | none                                |          0.0386 |             -3.86 | False    |

### C6a SE(3) re-randomisation checks (Eq. 26)

| check                                                       | result                |
|:------------------------------------------------------------|:----------------------|
| group closure: ||R^T R - I||_F after 4000 steps             | 1.77e-14              |
| monobit z over 1,024,000 key bits                           | +0.80                 |
| runs test z                                                 | +0.57                 |
| byte chi-square p-value                                     | 0.528                 |
| mean |corr| of successive keys (32 bit positions)           | 0.0128                |
| avalanche: bit flips for a 1e-09 change in rho (100 trials) | 1.2 of 256 (sd 12.0)  |
| avalanche: bit flips for a 1e-06 change in rho (100 trials) | 128.0 of 256 (sd 7.3) |
| avalanche: bit flips for a 0.001 change in rho (100 trials) | 127.3 of 256 (sd 7.6) |
| minimum pairwise distance between visited states            | 1.040e+00             |
| cost per re-randomisation step (expm 4x4 + KDF), us         | 33                    |

### C6b Predictability of the next state vs diffusion schedule

| diffusion schedule           |   next-state prediction error (Frobenius, last 100 steps) |
|:-----------------------------|----------------------------------------------------------:|
| sigma = 0.01 (floor)         |                                                    0.0281 |
| sigma = 0.05                 |                                                    0.1407 |
| sigma = 0.2                  |                                                    0.5603 |
| sigma = 0.6 (cap)            |                                                    1.6227 |
| sigma = 0.2/(1+t) (annealed) |                                                    0.0016 |

### C7 Scope of the Eq. 12 security statement

| level   | components                    |   NIST category (thesis) | Eq. 12 statement                     | what it covers                                                                      | does not cover                                                                              |
|:--------|:------------------------------|-------------------------:|:-------------------------------------|:------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| Pi_0    | ML-KEM-768 + X25519           |                        3 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |
| Pi_1    | ML-KEM-1024 + X25519          |                        5 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |
| Pi_2    | ML-KEM-1024 + mceliece6688128 |                        5 | lambda_PQ >= max(lambda_1, lambda_2) | key is secure if at least one component KEM is secure (IND-CCA combiner assumption) | implementation side channels; PQ strength of X25519 (none); the AEAD of the control channel |


Wall time 11s.
