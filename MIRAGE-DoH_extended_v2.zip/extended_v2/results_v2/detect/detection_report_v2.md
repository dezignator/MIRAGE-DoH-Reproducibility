# MIRAGE-DoH detection experiments (synthetic metadata)

### d1_seen_protocol

| detector                      | FPR                 | gan_flood   | *timing_probe   | downgrade   | tunnel   | *spectral_dga   | accuracy   |   mean AUC |
|:------------------------------|:--------------------|:------------|:----------------|:------------|:---------|:----------------|:-----------|-----------:|
| Rule-based                    | 1.56% [1.14%,2.13%] | 0.2%        | 92.4%           | 42.6%       | 100.0%   | 0.6%            | 72.80%     |      0.803 |
| Random Forest (sklearn)       | 1.16% [0.81%,1.66%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 100.0%          | 99.42%     |      1     |
| MLP (sklearn)                 | 1.32% [0.94%,1.85%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 0.0%            | 89.34%     |      0.803 |
| CMA alone                     | 0.68% [0.42%,1.09%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 65.2%           | 96.18%     |      0.978 |
| TMN alone                     | 1.28% [0.91%,1.80%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 1.0%            | 89.46%     |      0.928 |
| SGI alone                     | 0.64% [0.39%,1.04%] | 100.0%      | 100.0%          | 1.4%        | 93.4%    | 69.4%           | 86.10%     |      0.903 |
| MIRAGE ensemble (CMA+TMN+SGI) | 1.12% [0.78%,1.61%] | 100.0%      | 100.0%          | 100.0%      | 100.0%   | 63.0%           | 95.74%     |      0.991 |

### d1_all_protocol

| detector                      | FPR                 | gan_flood   | timing_probe   | downgrade   | tunnel   | spectral_dga   | accuracy   |   mean AUC |
|:------------------------------|:--------------------|:------------|:---------------|:------------|:---------|:---------------|:-----------|-----------:|
| Rule-based                    | 1.56% [1.14%,2.13%] | 0.2%        | 92.4%          | 42.6%       | 100.0%   | 0.6%           | 72.80%     |      0.803 |
| Random Forest (sklearn)       | 1.16% [0.81%,1.66%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.42%     |      1     |
| MLP (sklearn)                 | 0.72% [0.46%,1.14%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.64%     |      1     |
| CMA alone                     | 0.88% [0.58%,1.33%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.56%     |      1     |
| TMN alone                     | 1.08% [0.74%,1.57%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 99.8%          | 99.44%     |      1     |
| SGI alone                     | 0.56% [0.33%,0.94%] | 100.0%      | 100.0%         | 1.4%        | 93.4%    | 60.4%          | 85.24%     |      0.902 |
| MIRAGE ensemble (CMA+TMN+SGI) | 0.76% [0.49%,1.18%] | 100.0%      | 100.0%         | 100.0%      | 100.0%   | 100.0%         | 99.62%     |      1     |

### d1_cost

| scorer (given precomputed inputs)          |   us/window |
|:-------------------------------------------|------------:|
| Rule-based                                 |         0   |
| Random Forest (200 trees)                  |        51.1 |
| MLP                                        |         0.8 |
| CMA policy forward                         |         0.2 |
| TMN (diagram attention + LSTM, 3-window)   |       116.7 |
| SGI spectral classifier                    |         0.1 |
| metadata features (20) from a window       |       357.6 |
| persistence + spectral state from a window |     16849.3 |

### d1_throughput

| quantity                                               | value                      |
|:-------------------------------------------------------|:---------------------------|
| ensemble cost per 64-query window (us)                 | 17324                      |
| single-core queries/s (this implementation)            | 3,694                      |
| instances needed for 15.3M qps (Table 8) at this speed | 4,141                      |
| CPU per instance bound in Sec 3.4.2                    | < 5 % of resolver capacity |

### d1_ctai

| detector                      |   accuracy |    FPR |   CTAI (alpha=1,1,0 ; latency omitted) |
|:------------------------------|-----------:|-------:|---------------------------------------:|
| Rule-based                    |     0.728  | 0.0156 |                                 0.7124 |
| Random Forest (sklearn)       |     0.9942 | 0.0116 |                                 0.9826 |
| MLP (sklearn)                 |     0.9964 | 0.0072 |                                 0.9892 |
| CMA alone                     |     0.9956 | 0.0088 |                                 0.9868 |
| TMN alone                     |     0.9944 | 0.0108 |                                 0.9836 |
| SGI alone                     |     0.8524 | 0.0056 |                                 0.8468 |
| MIRAGE ensemble (CMA+TMN+SGI) |     0.9962 | 0.0076 |                                 0.9886 |

### d5_ablation

| components   | FPR   | TPR seen families   | TPR unseen (zero-day)   |   AUC unseen |
|:-------------|:------|:--------------------|:------------------------|-------------:|
| CMA          | 0.68% | 100.0%              | 82.6%                   |        0.946 |
| TMN          | 1.28% | 100.0%              | 50.5%                   |        0.819 |
| CMA+TMN      | 1.20% | 100.0%              | 72.7%                   |        0.948 |
| SGI          | 0.64% | 64.9%               | 84.7%                   |        0.991 |
| CMA+SGI      | 0.64% | 100.0%              | 89.0%                   |        0.981 |
| TMN+SGI      | 1.36% | 100.0%              | 53.1%                   |        0.886 |
| CMA+TMN+SGI  | 1.12% | 100.0%              | 81.5%                   |        0.977 |

### d2_curriculum

|   lambda (Fisher) | phase                         |   F1 (%) |   AUC | novelty zero-shot (%)   |   novelty after adaptation (%) | forgetting (%)   |   FPR (%) |
|------------------:|:------------------------------|---------:|------:|:------------------------|-------------------------------:|:-----------------|----------:|
|                 0 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 2 (dynamic threats)     |     66.7 | 1     | 50.0                    |                           50   | 0.0 ± 0.0        |         0 |
|                 0 | Phase 3 (live)                |    100   | 1     | 0.0                     |                          100   | 0.0 ± 0.0        |         0 |
|                10 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|                10 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|                10 | Phase 2 (dynamic threats)     |     44.4 | 0.728 | 50.0                    |                           33.3 | 33.3 ± 65.3      |         0 |
|                10 | Phase 3 (live)                |     99.8 | 1     | 0.3                     |                           99.2 | 0.0 ± 0.0        |         0 |
|               100 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|               100 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|               100 | Phase 2 (dynamic threats)     |     44.4 | 0.862 | 50.0                    |                           33.3 | 33.3 ± 65.3      |         0 |
|               100 | Phase 3 (live)                |     96.5 | 1     | 3.0                     |                           78   | 0.0 ± 0.0        |         0 |
|              1000 | Initialization                |    100   | 1     | -                       |                          100   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 1 (static morphologies) |     66.7 | 0.599 | 0.0                     |                            0   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 2 (dynamic threats)     |     66.7 | 0.727 | 50.0                    |                           50   | 0.0 ± 0.0        |         0 |
|              1000 | Phase 3 (live)                |     98.9 | 1     | 0.2                     |                           94   | 0.0 ± 0.0        |         0 |

### d3_tmn_hops

|   hops L |   P(edge observed) |   memory windows T |   detection |   bounded-RF baseline (R=35), full observation |
|---------:|-------------------:|-------------------:|------------:|-----------------------------------------------:|
|       10 |               0.95 |                  1 |       0.45  |                                              1 |
|       10 |               0.95 |                  3 |       1     |                                              1 |
|       10 |               0.99 |                  1 |       0.9   |                                              1 |
|       10 |               0.99 |                  3 |       1     |                                              1 |
|       30 |               0.95 |                  1 |       0.25  |                                              1 |
|       30 |               0.95 |                  3 |       1     |                                              1 |
|       30 |               0.99 |                  1 |       0.65  |                                              1 |
|       30 |               0.99 |                  3 |       1     |                                              1 |
|       50 |               0.95 |                  1 |       0.075 |                                              0 |
|       50 |               0.95 |                  3 |       1     |                                              0 |
|       50 |               0.99 |                  1 |       0.65  |                                              0 |
|       50 |               0.99 |                  3 |       1     |                                              0 |
|       80 |               0.95 |                  1 |       0     |                                              0 |
|       80 |               0.95 |                  3 |       0.975 |                                              0 |
|       80 |               0.99 |                  1 |       0.35  |                                              0 |
|       80 |               0.99 |                  3 |       1     |                                              0 |

### d3_permutation

| feature                                                    |   mean change |
|:-----------------------------------------------------------|--------------:|
| persistence diagram of the point cloud (relabelled points) |          0    |
| lag-1 autocorrelation (packet order shuffled)              |          0.39 |

### d4_sgi_dqn

| scenario                                    | state                       | accuracy    |   TPR |   FPR |   mean reward/step |
|:--------------------------------------------|:----------------------------|:------------|------:|------:|-------------------:|
| spectral_dga [target (structural)]          | spectral (k=16 eigenvalues) | 81.5 ± 5.8  |  98.3 |  21.9 |              0.029 |
| spectral_dga [target (structural)]          | flow metadata (20 features) | 99.4 ± 0.4  | 100   |   0.7 |              0.115 |
| gan_flood [negative control (flow-visible)] | spectral (k=16 eigenvalues) | 100.0 ± 0.0 | 100   |   0   |              0.117 |
| gan_flood [negative control (flow-visible)] | flow metadata (20 features) | 96.6 ± 1.6  | 100   |   4   |              0.045 |

### d6_levy_jumps

|   jump rate/step |   jump scale (x sigma) |   mean 1-BV/RV |    sd |   power @1% FPR |
|-----------------:|-----------------------:|---------------:|------:|----------------:|
|            0     |                      3 |          0.01  | 0.015 |      nan        |
|            0.005 |                      3 |          0.02  | 0.023 |        0.216667 |
|            0.005 |                      6 |          0.088 | 0.077 |        0.633333 |
|            0.01  |                      3 |          0.036 | 0.03  |        0.366667 |
|            0.01  |                      6 |          0.155 | 0.086 |        0.966667 |
|            0.02  |                      3 |          0.073 | 0.038 |        0.65     |
|            0.02  |                      6 |          0.273 | 0.092 |        1        |
