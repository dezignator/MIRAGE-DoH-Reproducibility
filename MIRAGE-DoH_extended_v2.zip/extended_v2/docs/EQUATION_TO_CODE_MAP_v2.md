# Equation / table to code map (Chapter 3)

| Thesis item | Implementation | Test / experiment |
|---|---|---|
| Eq. 1 policy pi_phi | `mirage_v2/cma_v2.py::prob`, `prob_pop` | `test_mirage_core_v2.py::TestCMA` |
| Eq. 2 evolutionary objective | `cma_v2.py::es_train` (R_cat subtracted; sign note in docstring) | D2 |
| Eq. 3 Fisher penalty R_cat | `cma_v2.py::fisher_diag`, `r_cat` | `TestCMA`, D2 |
| Eqs. 4-5 Hamiltonian, Ricci flow | not implemented (no algorithm specified) | - |
| Eqs. 6-8 filtration, persistence | `topology_v2.py::vr_persistence`, `flag_persistence` | `TestTopology` |
| Eq. 9 LSTM-attention | `tmn_v2.py::TMNEncoder` (fixed recurrent weights, trained read-out) | D1, D5 |
| Eq. 10 multi-hop kernel | relay-loop memory in `tmn_v2.py` (`add_relay_chain`, `chain_score`) | D3 |
| Eq. 11 KEM combiner | `mcs_v2.py::combine` | `TestMCS`, C2 |
| Eq. 12 PQ bound | statement only | C7 |
| Eq. 13 policy | `mcs_v2.py::select_level`, `AdaptiveThresholds` | `TestMCS`, C4 |
| Table 5 shard levels | `mcs_v2.py::LEVELS`, `handshake`, `wire_bytes` | C1, C3 |
| ML-KEM-512/768/1024 | `mlkem_v2.py` (FIPS 203 structure, not KAT validated) | `TestMLKEM`, C1 |
| Eqs. 14-16 causal engine | `cce_v2.py` | `TestCCEandSE3`, C5 |
| Eqs. 17, 20 Laplacian, edge weights | `sgi_v2.py::window_graph`, `laplacian` | `TestSGIandMetrics` |
| Eq. 18 spectral embedding | `sgi_v2.py::spectral_state` (spectrum instead of U_k^T L) | D4 |
| Eqs. 19, 21 DQN, reward | `sgi_v2.py::DQNAgent`, `REWARD` | D4 |
| Eqs. 22-23 Levy-type process | `levy_se3_v2.py::levy_path`, `bns_jump_stat` | D6 |
| Eq. 26 SE(3) flow | `levy_se3_v2.py::Rerandomizer` | C6 |
| Eq. 27 graph Wasserstein | `sgi_v2.py::spectral_wasserstein` (1-D proxy) | - |
| Eq. 28 QR_MCS, Eq. 30 QLR | not implemented (not well defined / not computable) | - |
| Eq. 29 CTAI | `metrics_v2.py::ctai` | D1e |
| Eq. 31 throughput | `metrics_v2.py::throughput`, `instances_for` | D1d, S6 |
| Tables 8-12 | no regeneration; compare `results_v2/system/claims_vs_simulation_v2.csv` | S-suite |
