# What can and cannot be regenerated without the original hardware

| Result in Chapter 3 | Needs | In this repository |
|---|---|---|
| 78 us scoring latency, 15.3 M qps (Table 8) | Loihi 2 + A100 + FPGA pipeline | no; CPU scoring cost and implied instance count are measured (D1c, D1d) |
| Morph time 3.8-9.5 ms (Tables 9, 12) | the authors' deployment, liboqs/McEliece implementation, network | no; compute is measured for pure-Python ML-KEM and X25519, bytes are exact, transfer is modelled (C3) |
| Classic McEliece timings | a McEliece implementation | not included; byte sizes only (`SizeModelKEM`) |
| Table 8-12 accuracy, FPR, recall | CIC-DoH2023, Gen-C-DDD-2022, CNN-LSTM baselines | no; synthetic traffic and scikit-learn baselines (D1, D5) |
| Table 10 curriculum | live adversarial environment | mechanism run on synthetic phases (D2) |
| Quantum-adversary simulation (Sec 3.18) | quantum simulator | no |
| Figures 2-6 | raw logs | analogous plots from the simulated runs only |
