"""Cognitive MetaAgent, Sec 3.5.4-3.5.5 (Eqs. 1-5).

Eq. (1)  policy pi_phi: window metadata -> P(action)       small MLP, actions {benign, flag}
Eq. (2)  phi_{t+1} = argmax E[F_novel(phi,X) + lambda*R_cat(phi)]
         implemented as an evolution strategy (antithetic, rank-shaped, Adam on the
         ES gradient estimate). R_cat enters as a PENALTY (Eq. 3 is a sum of squares and
         is subtracted from the fitness; the thesis writes '+lambda*R_cat').
         F_novel is the homological novelty of the window (distance of its persistence
         features from the benign archive) times the policy's flag probability: the
         agent is rewarded for responding to windows that are far from benign in
         homological space, on top of the supervised reward.
Eq. (3)  R_cat = sum_j F_j (phi_j - phi*_j)^2, F = diagonal empirical Fisher.
Eqs. (4)-(5) Hamiltonian / Ricci-flow formulations are abstractions in the thesis
         and are not implemented (no algorithm is specified); the Fisher-Rao metric
         enters here only through the diagonal Fisher penalty of Eq. (3).
"""
import numpy as np
from . import topology_v2 as topo
from . import traffic_v2 as tv

D, H = tv.D, 12
NP = D * H + H + H + 1


def sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def unpack(t):
    W1 = t[..., :D * H].reshape(t.shape[:-1] + (D, H))
    b1 = t[..., D * H:D * H + H]
    W2 = t[..., D * H + H:D * H + 2 * H]
    b2 = t[..., -1]
    return W1, b1, W2, b2


def init(rng):
    return np.concatenate([rng.normal(0, 1 / np.sqrt(D), D * H), np.zeros(H), rng.normal(0, 1 / np.sqrt(H), H), [0.0]])


def prob(theta, X):
    W1, b1, W2, b2 = unpack(theta)
    return sig(np.tanh(X @ W1 + b1) @ W2 + b2)


def prob_pop(Th, X):
    """Th (N,NP), X (B,D) -> (N,B)"""
    W1, b1, W2, b2 = unpack(Th)
    A = np.tanh(np.einsum("bd,ndh->nbh", X, W1) + b1[:, None])
    return sig(np.einsum("nbh,nh->nb", A, W2) + b2[:, None])


def fisher_diag(theta, X, y):
    """Empirical diagonal Fisher: mean squared per-sample gradient of the log-likelihood."""
    W1, b1, W2, b2 = unpack(theta)
    A = np.tanh(X @ W1 + b1); p = sig(A @ W2 + b2)
    dl = (p - y)[:, None]
    gW2 = dl * A
    gb2 = dl[:, 0]
    dZ = dl * W2[None, :] * (1 - A ** 2)
    gW1 = X[:, :, None] * dZ[:, None, :]
    G = np.concatenate([gW1.reshape(len(X), -1), dZ, gW2, gb2[:, None]], axis=1)
    return (G ** 2).mean(0)


def r_cat(theta, theta_star, F):
    """Eq. (3)."""
    return float(np.sum(F * (theta - theta_star) ** 2))


def r_cat_pop(Th, theta_star, F):
    return ((Th - theta_star) ** 2 * F).sum(1)


class Homological:
    """Window-level persistence features and the novelty score F_novel uses."""

    def __init__(self):
        self.mu = None

    @staticmethod
    def feats(win):
        x = np.log(np.diff(win["ts"]) + 1e-3)
        x = (x - x.mean()) / (x.std() + 1e-9)
        dg = topo.vr_persistence(topo.delay_embed(x, 4, 2), max_scale=1.2)[1]
        f = topo.finite(dg)
        life = (f[:, 1] - f[:, 0]) if len(f) else np.array([0.0])
        return np.array([topo.persistence_entropy(dg), life.max(), len(f)])

    def fit(self, benign_wins):
        F = np.array([self.feats(w) for w in benign_wins])
        self.mu = F.mean(0)
        self.Ci = np.linalg.inv(np.cov(F.T) + 1e-3 * np.eye(3))
        return self

    def novelty(self, wins=None, F=None):
        F = np.array([self.feats(w) for w in wins]) if F is None else F
        d = F - self.mu
        z = np.sqrt(np.einsum("ij,jk,ik->i", d, self.Ci, d))
        return 1 - np.exp(-z / 3.0)                 # in [0,1)


def es_train(theta0, X, y, nov, rng, gens=150, pop=48, sigma=0.12, lr=0.03, lam=0.0,
             theta_star=None, F=None, beta=0.1, fp_cost=2.0, batch=384, time_log=None):
    """Maximise  E[ -weighted BCE + beta*F_novel ] - lam*R_cat  by ES. Returns theta."""
    import time
    theta = theta0.copy()
    m = np.zeros(NP); v = np.zeros(NP)
    a1, a2, eps = 0.9, 0.999, 1e-8
    for g in range(1, gens + 1):
        t0 = time.perf_counter()
        idx = rng.integers(0, len(X), batch)
        Xb, yb, nb = X[idx], y[idx], nov[idx]
        E = rng.normal(0, 1, (pop // 2, NP))
        E = np.concatenate([E, -E])
        Th = theta + sigma * E
        P = prob_pop(Th, Xb)
        wts = np.where(yb == 1, 1.0, fp_cost)
        ll = -(wts * (yb * np.log(P + 1e-9) + (1 - yb) * np.log(1 - P + 1e-9))).mean(1)
        fit = -ll + beta * (P * nb).mean(1)
        if lam > 0 and theta_star is not None:
            fit = fit - lam * r_cat_pop(Th, theta_star, F)
        r = np.argsort(np.argsort(fit)) / (len(fit) - 1) - 0.5          # centred ranks
        grad = (r[:, None] * E).sum(0) / (len(E) * sigma)
        m = a1 * m + (1 - a1) * grad; v = a2 * v + (1 - a2) * grad ** 2
        theta = theta + lr * (m / (1 - a1 ** g)) / (np.sqrt(v / (1 - a2 ** g)) + eps)
        if time_log is not None:
            time_log.append(time.perf_counter() - t0)
    return theta


def f1_auc(theta, X, y):
    p = prob(theta, X)
    pred = p >= 0.5
    tp = int((pred & (y == 1)).sum()); fp = int((pred & (y == 0)).sum()); fn = int((~pred & (y == 1)).sum())
    f1 = 2 * tp / max(2 * tp + fp + fn, 1)
    r = np.argsort(np.argsort(p)) + 1
    n1, n0 = int((y == 1).sum()), int((y == 0).sum())
    auc = (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
    return f1, float(auc), float(pred[y == 1].mean()), float(pred[y == 0].mean())
