"""MIRAGE-DoH Chapter 3 -- extended reference implementations (v2).

Modules map to numbered equations of the thesis; see
docs/EQUATION_TO_CODE_MAP_v2.md.  Software references: nothing here runs on
Loihi 2 / A100 / FPGA, and all traffic is simulated.
"""
__version__ = "2.0.0"
