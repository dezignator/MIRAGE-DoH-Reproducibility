"""Synthetic encrypted-DNS windows for the five attack types of Table 6 plus
benign traffic, and the 20 metadata features of Sec 3.4.1.

Only metadata that is observable without decrypting TLS is used: inter-arrival
times, sizes, label statistics, TLS negotiation indicators and HTTP/3 frame
ordering. Scenario parameters are mine; they are not CIC-DoH2023 /
Gen-C-DDD-2022 and results built on them are not Tables 8-12.
"""
import math
from collections import Counter
import numpy as np

W = 64
KINDS = ["benign", "gan_flood", "timing_probe", "downgrade", "tunnel", "spectral_dga"]
ATTACKS = KINDS[1:]
FEATURE_NAMES = ["log_mean_iat", "iat_cv", "size_mean", "size_sd", "ent_mean", "ent_sd", "label_len",
                 "uniq_label_frac", "rare_qtype_frac", "ac1", "ac_peak", "tls12_frac", "ext_count_sd",
                 "hs_rate", "hs_time_cv", "ecs_frac", "frame_entropy", "fano", "lowband_power", "uniq_domain_rate"]
D = len(FEATURE_NAMES)
_B32 = list("abcdefghijklmnopqrstuvwxyz234567")
_HEX = list("0123456789abcdef")
_WORDS = ["mail", "www", "api", "cdn", "img", "login", "static", "update", "pay", "docs", "shop", "news",
          "maps", "video", "cloud", "auth", "files", "chat", "app", "store"]
_SYL = ["ka", "to", "mi", "re", "su", "no", "la", "vi", "da", "po", "ne", "ru", "so", "ti", "bo", "xe"]


def entropy(s):
    if not s:
        return 0.0
    c = Counter(s); n = len(s)
    return -sum(v / n * math.log2(v / n) for v in c.values())


def _rl(rng, alpha, n):
    return "".join(rng.choice(alpha, n))


def _frames(rng, n, p_data):
    """HTTP/3 frame-type sequence (0 HEADERS, 1 DATA, 2 SETTINGS, 3 other)."""
    return rng.choice(4, n, p=p_data)


def gen_window(kind, rng, w=W):
    meta = dict(tls12=0.0, ext_sd=0.2, hs=0.05, hs_cv=0.45, ecs=0.1, frames=[0.35, 0.5, 0.05, 0.1])
    if kind == "benign":
        r = rng.random()
        if r < 0.15:
            p = rng.uniform(2, 10)
            ts = np.cumsum(p * (1 + rng.normal(0, 0.05, w)).clip(0.5))
            names = [f"time{rng.integers(0, 3)}.vendor{rng.integers(0, 4)}.com" for _ in range(w)]
            size = rng.normal(100, 6, w)
        elif r < 0.27:
            ts = np.cumsum(rng.lognormal(-1.0, 0.9, w))
            names = [f"{_rl(rng, _HEX, int(rng.integers(8, 20)))}.cdn{rng.integers(0, 5)}.net" for _ in range(w)]
            size = rng.normal(130, 25, w)
        else:
            ts = np.cumsum(rng.lognormal(-1.0, 1.1, w))
            names = [f"{rng.choice(_WORDS)}{rng.integers(0, 60)}.site{rng.integers(0, 30)}.org" for _ in range(w)]
            size = rng.normal(120, 28, w)
        qt = rng.choice(6, w, p=[0.62, 0.30, 0.03, 0.02, 0.025, 0.005])
        meta["tls12"] = float(rng.random() < 0.06) * rng.uniform(0.2, 0.6)     # some legacy clients
        meta["ecs"] = rng.uniform(0.0, 0.3)
    elif kind == "gan_flood":
        ts = np.cumsum(rng.exponential(rng.uniform(0.01, 0.05), w))
        names = []
        for _ in range(w):
            lab = "".join(rng.choice(_SYL, int(rng.integers(3, 6))))
            names.append(f"{lab}{rng.integers(0, 999)}.{rng.choice(_WORDS)}.gen{rng.integers(0, 4)}.com")
        size = rng.normal(140, 20, w)
        qt = rng.choice(6, w, p=[0.7, 0.25, 0.02, 0.01, 0.015, 0.005])
        meta.update(hs=0.04, ecs=rng.uniform(0.0, 0.3))
    elif kind == "timing_probe":
        ts = np.cumsum(np.abs(rng.normal(0.005, 0.0004, w)))
        names = [f"probe.target{rng.integers(0, 2)}.org" for _ in range(w)]
        size = rng.normal(90, 2, w)
        qt = rng.choice(6, w, p=[0.9, 0.1, 0, 0, 0, 0])
        meta.update(hs=rng.uniform(0.7, 0.95), hs_cv=rng.uniform(0.02, 0.1), ext_sd=0.0, ecs=0.0,
                    frames=[0.45, 0.45, 0.05, 0.05])
    elif kind == "downgrade":
        ts = np.cumsum(rng.lognormal(-1.0, 1.0, w))
        names = [f"{rng.choice(_WORDS)}{rng.integers(0, 60)}.site{rng.integers(0, 30)}.org" for _ in range(w)]
        size = rng.normal(125, 28, w)
        qt = rng.choice(6, w, p=[0.62, 0.30, 0.03, 0.02, 0.025, 0.005])
        meta.update(tls12=rng.uniform(0.3, 0.9), ecs=rng.uniform(0.4, 0.9), ext_sd=rng.uniform(0.6, 1.5),
                    hs=rng.uniform(0.2, 0.5))
    elif kind == "tunnel":
        ts = np.cumsum(rng.exponential(rng.uniform(4, 15), w))
        L = int(rng.integers(26, 46))
        names = [f"{_rl(rng, _B32, L)}.t{rng.integers(0, 3)}.evil.net" for _ in range(w)]
        size = rng.normal(210, 18, w)
        qt = rng.choice(6, w, p=[0.1, 0.05, 0.55, 0.1, 0.15, 0.05])
        meta.update(hs=0.03, frames=[0.3, 0.6, 0.03, 0.07])
    elif kind == "spectral_dga":
        # rate modulated by a slow sinusoid (about 2 cycles per window), dictionary-concatenated names
        phase = rng.uniform(0, 6.28)
        base = rng.lognormal(-1.0, 0.7, w)
        mod = 1 + 0.9 * np.sin(2 * np.pi * np.arange(w) * rng.uniform(1.6, 2.6) / w + phase)
        ts = np.cumsum(base * mod.clip(0.1))
        names = [f"{rng.choice(_WORDS)}{rng.choice(_WORDS)}{rng.integers(0, 99)}.{_rl(rng, _HEX, 2)}site.org" for _ in range(w)]
        size = rng.normal(122, 26, w)
        qt = rng.choice(6, w, p=[0.62, 0.30, 0.03, 0.02, 0.025, 0.005])
    else:
        raise ValueError(kind)
    n_ext = np.clip(rng.normal(10, meta["ext_sd"], w), 4, 20)
    hs_t = rng.lognormal(math.log(1.0), meta["hs_cv"], w)
    fr = _frames(rng, w, meta["frames"])
    return dict(kind=kind, ts=ts, size=np.clip(size, 40, 512), names=names, qt=np.asarray(qt),
                tls12=meta["tls12"], ext=n_ext, hs=meta["hs"], hs_t=hs_t, ecs=meta["ecs"], frames=fr)


def window_features(win):
    ts, size, names = win["ts"], win["size"], win["names"]
    iat = np.diff(ts)
    lab = [n.split(".")[0] for n in names]
    ent = np.array([entropy(x) for x in lab])
    x = (iat - iat.mean()) / (iat.std() + 1e-9)
    ac = [float(np.mean(x[:-k] * x[k:])) for k in range(1, 9)]
    fr = np.bincount(win["frames"], minlength=4) / len(win["frames"])
    frame_ent = -float(np.sum(fr[fr > 0] * np.log2(fr[fr > 0])))
    edges = np.linspace(ts[0], ts[-1] + 1e-9, 17)
    cnt = np.histogram(ts, bins=edges)[0].astype(float)
    spec = np.abs(np.fft.rfft(cnt - cnt.mean())) ** 2
    low = spec[1:4].sum() / (spec[1:].sum() + 1e-9)
    dom2 = {".".join(n.split(".")[-2:]) for n in names}
    return np.array([
        np.log(iat.mean() + 1e-3), iat.std() / (iat.mean() + 1e-9), size.mean() / 100, size.std() / 30,
        ent.mean(), ent.std(), np.mean([len(x) for x in lab]) / 10, len(set(lab)) / len(lab),
        float(np.mean(win["qt"] >= 3)), ac[0], max(ac[1:]), win["tls12"], float(np.std(win["ext"])),
        win["hs"], float(np.std(win["hs_t"]) / (np.mean(win["hs_t"]) + 1e-9)), win["ecs"], frame_ent,
        float(cnt.var() / (cnt.mean() + 1e-9)), float(low), len(dom2) / max(ts[-1] - ts[0], 1e-3),
    ])


def make_windows(kind, n, rng):
    return [gen_window(kind, rng) for _ in range(n)]


def make_features(kind, n, rng):
    return np.array([window_features(gen_window(kind, rng)) for _ in range(n)])


def morph(F, strength, mu_benign, rng, noise=0.05):
    """Mimicry operator used for 'adversarial morphologies': move an attack
    feature vector a fraction `strength` of the way to the benign mean, plus noise."""
    F = np.atleast_2d(F)
    sd = np.maximum(np.abs(mu_benign) * 0.05, 1e-3)
    return F + strength * (mu_benign - F) + rng.normal(0, 1, F.shape) * sd * noise
