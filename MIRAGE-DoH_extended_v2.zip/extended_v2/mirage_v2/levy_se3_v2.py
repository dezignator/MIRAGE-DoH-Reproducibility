"""Lévy-type traffic process (Eqs. 22-23) and SE(3) re-randomisation flow (Eq. 26).

Eq. (22)  L_t = int sigma dW + sum_i Phi_i : simulated and probed with the
          Barndorff-Nielsen-Shephard jump test (realised variance vs bipower variation).
Eq. (26)  dK_t = K_t xi_t dt + K_t Sigma dW_t on SE(3), advanced by K_{t+1} = K_t expm(xi dt + Sigma dW);
          the quantised state feeds a KDF. As the thesis states, no security property is
          derived from the flow; the statistical checks here only verify the properties the
          text relies on (group closure, bounded non-zero diffusion, unpredictability of
          the next state given the current one).
"""
import hashlib
import numpy as np
from scipy.linalg import expm


# ------------------------------------------------------------------ Eq. 22
def levy_path(n, sigma, jump_rate, jump_scale, rng, dt=1.0):
    """Increments of  sigma dW + compound Poisson jumps (Gaussian jump sizes)."""
    diff = rng.normal(0, sigma * np.sqrt(dt), n)
    nj = rng.poisson(jump_rate * dt, n)
    jumps = np.array([rng.normal(0, jump_scale, k).sum() if k else 0.0 for k in nj])
    return diff + jumps, nj > 0


def bns_jump_stat(r):
    """Ratio statistic  1 - BV/RV  in [0,1): near 0 for pure diffusion, larger with jumps.
    RV = sum r^2;  BV = (pi/2) sum |r_i||r_{i-1}|."""
    r = np.asarray(r, float)
    rv = np.sum(r ** 2)
    bv = (np.pi / 2) * np.sum(np.abs(r[1:]) * np.abs(r[:-1]))
    return float(max(0.0, 1 - bv / rv)) if rv > 0 else 0.0


# ------------------------------------------------------------------ Eq. 26
def hat(w):
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])


def se3_algebra(xi6):
    M = np.zeros((4, 4)); M[:3, :3] = hat(xi6[:3]); M[:3, 3] = xi6[3:]
    return M


class Rerandomizer:
    """K_{t+1} = K_t expm( xi_t dt + Sigma dW ),  K_0 = I."""

    def __init__(self, sigma_min=0.05, sigma_max=0.6, seed=0, anneal=False):
        self.rng = np.random.default_rng(seed)
        self.smin, self.smax, self.anneal = sigma_min, sigma_max, anneal
        self.K = np.eye(4); self.t = 0
        self.W1 = self.rng.normal(0, 0.3, (16, 6)); self.b1 = np.zeros(16)
        self.W2 = self.rng.normal(0, 0.3, (6, 16))

    def xi(self, rho, H, j):
        x = np.array([rho, H, j / 2.0, rho * H, np.sin(self.t * 0.1), 1.0])
        h = np.tanh(self.W1 @ x + self.b1)
        v = self.W2 @ h                                  # Pi_g: output already lies in se(3) coordinates
        return v

    def sigma(self, kl):
        """Diffusion magnitude from the KL divergence of observed vs baseline traffic,
        held in [sigma_min, sigma_max] and (unless anneal=True, the 'bad' variant the
        thesis argues against) not decayed with t."""
        s = float(np.clip(self.smin + 0.2 * kl, self.smin, self.smax))
        return s / (1 + self.t) if self.anneal else s

    def step(self, rho, H, j, kl, dt=1.0):
        s = self.sigma(kl)
        dW = self.rng.normal(0, np.sqrt(dt), 6)
        self.K = self.K @ expm(se3_algebra(self.xi(rho, H, j) * dt + s * dW))
        self.t += 1
        return self.K

    def key(self, ctx=b""):
        q = np.round(self.K * 2 ** 20).astype(np.int64).tobytes()
        return hashlib.shake_256(b"MIRAGE-SE3" + q + ctx).digest(32)

    def group_error(self):
        R = self.K[:3, :3]
        return float(np.linalg.norm(R.T @ R - np.eye(3)))


def predict_next_error(sigma_fn, n=400, seed=0):
    """How well an observer who knows K_t and the control velocity xi_t predicts K_{t+1}
    (deterministic part only): mean Frobenius error of the noise-free propagation."""
    r = Rerandomizer(seed=seed)
    errs = []
    for t in range(n):
        s = sigma_fn(t)
        xi = r.xi(0.5, 0.5, 1)
        K_pred = r.K @ expm(se3_algebra(xi))
        dW = r.rng.normal(0, 1, 6)
        r.K = r.K @ expm(se3_algebra(xi + s * dW))
        errs.append(np.linalg.norm(r.K - K_pred))
    return float(np.mean(errs[-100:]))
