"""Metamorphic Cryptographic Shards, Sec 3.7 (Eqs. 11-13), Table 5.

 - KEM combiner (Eq. 11): K_ctrl = KDF(ss1 || ss2 || ct1 || ct2 || ctx), SHAKE256,
   each field length-prefixed (plain concatenation is injective only for fixed sizes),
   control metadata sealed with ChaCha20-Poly1305 (AEAD.Enc(K_ctrl, m)).
 - Real components: X25519 (cryptography), ML-KEM-768/1024 (mlkem_v2.py, educational).
 - Classic McEliece mceliece6688128: NO implementation is included. `SizeModelKEM`
   reproduces its byte sizes (pk 1,044,992 B, ct 208 B, ss 32 B) with a keyed toy
   mapping so the protocol logic and bandwidth accounting can be exercised. It
   provides no security whatsoever and its timings are reported as not measured.
 - Policy (Eq. 13): three levels with a hard floor at Pi_0.
"""
import hashlib
import os
import time
from dataclasses import dataclass

import numpy as np

from .mlkem_v2 import MLKEM

try:
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
    from cryptography.hazmat.primitives import serialization
    HAVE_CRYPTO = True
except Exception:                                                        # pragma: no cover
    HAVE_CRYPTO = False

MCELIECE_SIZES = dict(pk=1_044_992, sk=13_932, ct=208, ss=32)            # mceliece6688128
LEVELS = {
    0: dict(name="Pi_0", kems=("ML-KEM-768", "X25519"), nist_category=3),
    1: dict(name="Pi_1", kems=("ML-KEM-1024", "X25519"), nist_category=5),
    2: dict(name="Pi_2", kems=("ML-KEM-1024", "mceliece6688128"), nist_category=5),
}


def kdf(*parts, out=32):
    h = hashlib.shake_256(b"MIRAGE-DoH/MCS/v2")
    for p in parts:
        h.update(len(p).to_bytes(4, "big")); h.update(p)
    return h.digest(out)


def combine(ss1, ss2, ct1, ct2, ctx):
    """Eq. (11)."""
    return kdf(ss1, ss2, ct1, ct2, ctx)


def seal(key, m, ad=b""):
    n = os.urandom(12)
    return n + ChaCha20Poly1305(key).encrypt(n, m, ad)


def open_(key, blob, ad=b""):
    return ChaCha20Poly1305(key).decrypt(blob[:12], blob[12:], ad)


class X25519KEM:
    name = "X25519"
    sizes = dict(ek=32, dk=32, ct=32, ss=32)

    def keygen(self):
        sk = X25519PrivateKey.generate()
        raw = lambda k, f: k.public_bytes(serialization.Encoding.Raw, f) if f is None else None
        pk = sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        dk = sk.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
        return pk, dk

    def encaps(self, pk):
        e = X25519PrivateKey.generate()
        ct = e.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return e.exchange(X25519PublicKey.from_public_bytes(pk)), ct

    def decaps(self, dk, ct):
        return X25519PrivateKey.from_private_bytes(dk).exchange(X25519PublicKey.from_public_bytes(ct))


class SizeModelKEM:
    """Byte-size model of Classic McEliece mceliece6688128. NOT a KEM."""
    name = "mceliece6688128 (size model)"
    sizes = dict(ek=MCELIECE_SIZES["pk"], dk=MCELIECE_SIZES["sk"], ct=MCELIECE_SIZES["ct"], ss=32)

    def keygen(self):
        ident = os.urandom(32)
        return ident + b"\0" * (self.sizes["ek"] - 32), ident

    def encaps(self, pk):
        ss, nonce = os.urandom(32), os.urandom(176)
        mask = hashlib.shake_256(pk[:32] + nonce).digest(32)
        return ss, nonce + bytes(a ^ b for a, b in zip(ss, mask))

    def decaps(self, dk, ct):
        mask = hashlib.shake_256(dk + ct[:176]).digest(32)
        return bytes(a ^ b for a, b in zip(ct[176:], mask))


class _MLKEMAdapter:
    def __init__(self, name):
        self.k = MLKEM(name); self.name = name; self.sizes = self.k.sizes

    def keygen(self): return self.k.keygen()
    def encaps(self, pk): return self.k.encaps(pk)
    def decaps(self, dk, ct): return self.k.decaps(dk, ct)


def make_kem(name):
    if name == "X25519":
        return X25519KEM()
    if name.startswith("ML-KEM"):
        return _MLKEMAdapter(name)
    return SizeModelKEM()


# ----------------------------------------------------------------- policy, Eq. (13)
def select_level(rho, g1, g2):
    if not (0 <= g1 <= g2 <= 1):
        raise ValueError("need 0 <= gamma1 <= gamma2 <= 1")
    return 0 if rho <= g1 else (1 if rho <= g2 else 2)


class AdaptiveThresholds:
    """gamma_1, gamma_2 from an EWMA of recent threat scores: they rise with the
    background level so routine noise does not hold the shard at a high level,
    but are clipped into [lo, hi] so they can never push selection below Pi_0
    (the floor is structural: select_level never returns less than 0) and a
    saturated adversary cannot raise them past `hi`."""

    def __init__(self, g1=0.3, g2=0.7, alpha=0.02, lo=(0.2, 0.5), hi=(0.5, 0.9)):
        self.g1, self.g2, self.alpha, self.lo, self.hi = g1, g2, alpha, lo, hi
        self.base = (g1, g2); self.m = 0.0

    def update(self, rho):
        self.m = (1 - self.alpha) * self.m + self.alpha * rho
        self.g1 = float(np.clip(self.base[0] + 0.5 * self.m, *(self.lo[0], self.hi[0])))
        self.g2 = float(np.clip(self.base[1] + 0.5 * self.m, *(self.lo[1], self.hi[1])))
        return self.g1, self.g2


# ----------------------------------------------------------------- handshake
@dataclass
class Handshake:
    level: int
    key: bytes
    wire_c2s: int
    wire_s2c: int
    t: dict


def handshake(level, ctx=b"session-0", msg=b"control-metadata", pre_provisioned_pk2=False):
    """Run one control-plane key establishment for a shard at `level`; returns the
    derived key, wire bytes in each direction and stage timings (seconds)."""
    names = LEVELS[level]["kems"]
    k1, k2 = make_kem(names[0]), make_kem(names[1])
    t = {}
    t0 = time.perf_counter(); pk1, sk1 = k1.keygen(); t["keygen_kem1"] = time.perf_counter() - t0
    t0 = time.perf_counter(); pk2, sk2 = k2.keygen(); t["keygen_kem2"] = time.perf_counter() - t0
    t0 = time.perf_counter(); ss1, ct1 = k1.encaps(pk1); t["encaps_kem1"] = time.perf_counter() - t0
    t0 = time.perf_counter(); ss2, ct2 = k2.encaps(pk2); t["encaps_kem2"] = time.perf_counter() - t0
    t0 = time.perf_counter(); d1 = k1.decaps(sk1, ct1); t["decaps_kem1"] = time.perf_counter() - t0
    t0 = time.perf_counter(); d2 = k2.decaps(sk2, ct2); t["decaps_kem2"] = time.perf_counter() - t0
    assert d1 == ss1 and d2 == ss2
    t0 = time.perf_counter(); key = combine(ss1, ss2, ct1, ct2, ctx); t["combine_kdf"] = time.perf_counter() - t0
    t0 = time.perf_counter(); blob = seal(key, msg, ctx); t["aead_seal"] = time.perf_counter() - t0
    t0 = time.perf_counter(); assert open_(key, blob, ctx) == msg; t["aead_open"] = time.perf_counter() - t0
    pk_bytes = len(pk1) + (0 if pre_provisioned_pk2 else len(pk2))
    return Handshake(level, key, pk_bytes, len(ct1) + len(ct2) + len(blob), t)


def wire_bytes(level, pre_provisioned_pk2=False):
    a, b = (make_kem(n).sizes for n in LEVELS[level]["kems"])
    return dict(client_to_server=a["ek"] + (0 if pre_provisioned_pk2 else b["ek"]),
                server_to_client=a["ct"] + b["ct"] + 12 + 16 + 16)


def transfer_ms(nbytes, mbps, rtt_ms, rtts=1):
    return nbytes * 8 / (mbps * 1e6) * 1e3 + rtts * rtt_ms
