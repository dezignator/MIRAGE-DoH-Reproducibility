"""ML-KEM (FIPS 203 structure) in pure Python, parameter sets 512/768/1024.

EDUCATIONAL REFERENCE. It follows the algorithm structure of FIPS 203
(K-PKE + Fujisaki-Okamoto with implicit rejection, NTT over Z_3329[x]/(x^256+1),
SHA3/SHAKE) and reproduces the standard key/ciphertext sizes, but it has NOT been
validated against the official known-answer tests, is not constant-time and is
roughly two orders of magnitude slower than liboqs. Do not use it to protect data.
Timings measured with it are therefore upper bounds for a native implementation.
"""
import hashlib
import os

Q, N = 3329, 256
PARAMS = {  # k, eta1, eta2, du, dv
    "ML-KEM-512": (2, 3, 2, 10, 4),
    "ML-KEM-768": (3, 2, 2, 10, 4),
    "ML-KEM-1024": (4, 2, 2, 11, 5),
}


def _brv7(i):
    return int(f"{i:07b}"[::-1], 2)


ZETAS = [pow(17, _brv7(i), Q) for i in range(128)]
GAMMAS = [pow(17, 2 * _brv7(i) + 1, Q) for i in range(128)]


def ntt(f):
    f = list(f); i = 1; ln = 128
    while ln >= 2:
        for start in range(0, 256, 2 * ln):
            z = ZETAS[i]; i += 1
            for j in range(start, start + ln):
                t = z * f[j + ln] % Q
                f[j + ln] = (f[j] - t) % Q
                f[j] = (f[j] + t) % Q
        ln //= 2
    return f


def ntt_inv(f):
    f = list(f); i = 127; ln = 2
    while ln <= 128:
        for start in range(0, 256, 2 * ln):
            z = ZETAS[i]; i -= 1
            for j in range(start, start + ln):
                t = f[j]
                f[j] = (t + f[j + ln]) % Q
                f[j + ln] = z * (f[j + ln] - t) % Q
        ln *= 2
    return [x * 3303 % Q for x in f]


def mul_ntt(a, b):
    h = [0] * 256
    for i in range(128):
        a0, a1, b0, b1 = a[2 * i], a[2 * i + 1], b[2 * i], b[2 * i + 1]
        h[2 * i] = (a0 * b0 + a1 * b1 % Q * GAMMAS[i]) % Q
        h[2 * i + 1] = (a0 * b1 + a1 * b0) % Q
    return h


def add(a, b):
    return [(x + y) % Q for x, y in zip(a, b)]


def sub(a, b):
    return [(x - y) % Q for x, y in zip(a, b)]


def byte_encode(F, d):
    acc = 0
    for i, c in enumerate(F):
        acc |= c << (i * d)
    return acc.to_bytes(32 * d, "little")


def byte_decode(B, d):
    acc = int.from_bytes(B, "little"); m = (1 << d) - 1
    F = [(acc >> (i * d)) & m for i in range(256)]
    return [x % Q for x in F] if d == 12 else F


def compress(x, d):
    return ((x << (d + 1)) + Q) // (2 * Q) & ((1 << d) - 1)


def decompress(y, d):
    return (Q * y + (1 << (d - 1))) >> d


def sample_ntt(rho, j, i):
    seed = rho + bytes([j, i]); ln = 1008
    while True:
        B = hashlib.shake_128(seed).digest(ln)
        a, p, k = [0] * 256, 0, 0
        while p < 256 and k + 3 <= ln:
            d1 = B[k] + 256 * (B[k + 1] & 15)
            d2 = (B[k + 1] >> 4) + 16 * B[k + 2]
            k += 3
            if d1 < Q:
                a[p] = d1; p += 1
            if d2 < Q and p < 256:
                a[p] = d2; p += 1
        if p == 256:
            return a
        ln *= 2


def prf(s, b, eta):
    return hashlib.shake_256(s + bytes([b])).digest(64 * eta)


def cbd(B, eta):
    big = int.from_bytes(B, "little"); f = []
    for i in range(256):
        x = sum((big >> (2 * i * eta + j)) & 1 for j in range(eta))
        y = sum((big >> (2 * i * eta + eta + j)) & 1 for j in range(eta))
        f.append((x - y) % Q)
    return f


def _matrix(rho, k):
    return [[sample_ntt(rho, j, i) for j in range(k)] for i in range(k)]


def G(b):
    return hashlib.sha3_512(b).digest()


def Hh(b):
    return hashlib.sha3_256(b).digest()


def J(b):
    return hashlib.shake_256(b).digest(32)


class MLKEM:
    def __init__(self, name="ML-KEM-768"):
        self.name = name
        self.k, self.eta1, self.eta2, self.du, self.dv = PARAMS[name]
        k = self.k
        self.sizes = dict(ek=384 * k + 32, dk=768 * k + 96, ct=32 * (self.du * k + self.dv), ss=32)

    # ---- K-PKE ----
    def _pke_keygen(self, d):
        k = self.k
        g = G(d + bytes([k])); rho, sigma = g[:32], g[32:]
        A = _matrix(rho, k)
        s = [ntt(cbd(prf(sigma, i, self.eta1), self.eta1)) for i in range(k)]
        e = [ntt(cbd(prf(sigma, k + i, self.eta1), self.eta1)) for i in range(k)]
        t = []
        for i in range(k):
            acc = e[i]
            for j in range(k):
                acc = add(acc, mul_ntt(A[i][j], s[j]))
            t.append(acc)
        ek = b"".join(byte_encode(x, 12) for x in t) + rho
        dk = b"".join(byte_encode(x, 12) for x in s)
        return ek, dk

    def _pke_enc(self, ek, m, r):
        k, du, dv = self.k, self.du, self.dv
        t = [byte_decode(ek[384 * i:384 * (i + 1)], 12) for i in range(k)]
        rho = ek[384 * k:]
        A = _matrix(rho, k)
        y = [ntt(cbd(prf(r, i, self.eta1), self.eta1)) for i in range(k)]
        e1 = [cbd(prf(r, k + i, self.eta2), self.eta2) for i in range(k)]
        e2 = cbd(prf(r, 2 * k, self.eta2), self.eta2)
        u = []
        for i in range(k):
            acc = [0] * 256
            for j in range(k):
                acc = add(acc, mul_ntt(A[j][i], y[j]))
            u.append(add(ntt_inv(acc), e1[i]))
        mu = [((m[i // 8] >> (i % 8)) & 1) * ((Q + 1) // 2) for i in range(256)]
        acc = [0] * 256
        for i in range(k):
            acc = add(acc, mul_ntt(t[i], y[i]))
        v = add(add(ntt_inv(acc), e2), mu)
        c1 = b"".join(byte_encode([compress(x, du) for x in ui], du) for ui in u)
        c2 = byte_encode([compress(x, dv) for x in v], dv)
        return c1 + c2

    def _pke_dec(self, dk, c):
        k, du, dv = self.k, self.du, self.dv
        c1, c2 = c[:32 * du * k], c[32 * du * k:]
        u = [[decompress(x, du) for x in byte_decode(c1[32 * du * i:32 * du * (i + 1)], du)] for i in range(k)]
        v = [decompress(x, dv) for x in byte_decode(c2, dv)]
        s = [byte_decode(dk[384 * i:384 * (i + 1)], 12) for i in range(k)]
        acc = [0] * 256
        for i in range(k):
            acc = add(acc, mul_ntt(s[i], ntt(u[i])))
        w = sub(v, ntt_inv(acc))
        bits = [compress(x, 1) for x in w]
        return bytes(sum(bits[8 * i + j] << j for j in range(8)) for i in range(32))

    # ---- KEM ----
    def keygen(self, d=None, z=None):
        d = d or os.urandom(32); z = z or os.urandom(32)
        ek, dkp = self._pke_keygen(d)
        return ek, dkp + ek + Hh(ek) + z

    def encaps(self, ek, m=None):
        m = m or os.urandom(32)
        g = G(m + Hh(ek)); K, r = g[:32], g[32:]
        return K, self._pke_enc(ek, m, r)

    def decaps(self, dk, c):
        k = self.k
        dkp, ek = dk[:384 * k], dk[384 * k:768 * k + 32]
        h, z = dk[768 * k + 32:768 * k + 64], dk[768 * k + 64:]
        m2 = self._pke_dec(dkp, c)
        g = G(m2 + h); K2, r2 = g[:32], g[32:]
        Kbar = J(z + c)
        return K2 if self._pke_enc(ek, m2, r2) == c else Kbar
