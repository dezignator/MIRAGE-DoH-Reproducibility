"""Spectral Game Intelligence, Sec 3.9 (Eqs. 17-21).

 Eq. (17)  L = D - A on the temporal-proximity graph of a window
 Eq. (20)  edge weight w_ij = exp(-dt_ij / tau), tau = 100 ms
 Eq. (18)  spectral embedding with k = 16: the state used here is the k smallest
           eigenvalues of the symmetric normalised Laplacian (permutation invariant);
           the thesis's X = U_k^T L is not a well-posed state (shape depends on the
           window) and is therefore replaced by the spectrum.
 Eqs. (19),(21) DQN with hidden layers 256-128-64, replay 100,000, target update
           every 1,000 steps, reward r = R_prevention - C_operation.
"""
import numpy as np

K_SPEC = 16
TAU = 0.1
ACTIONS = ["no-op", "rate-limit", "selective-block", "traffic-padding"]


def window_graph(ts, tau=TAU, w_min=0.01):
    ts = np.asarray(ts, float)
    dt = np.abs(ts[:, None] - ts[None, :])
    A = np.exp(-dt / tau)
    np.fill_diagonal(A, 0.0)
    A[A < w_min] = 0.0
    return A


def laplacian(A, normalized=True):
    d = A.sum(1)
    L = np.diag(d) - A                                    # Eq. (17)
    if not normalized:
        return L
    s = 1.0 / np.sqrt(np.maximum(d, 1e-12))
    return np.eye(len(A)) - s[:, None] * A * s[None, :]


def spectral_state(ts, k=K_SPEC, tau=TAU):
    A = window_graph(ts, tau)
    lam = np.linalg.eigvalsh(laplacian(A))
    return lam[:k]


def spectral_wasserstein(lam1, lam2, p=1):
    """W_p between the empirical spectra of two graphs (1-D optimal transport), the
    computable proxy used here for the graph-Wasserstein distance of Eq. (27)."""
    a, b = np.sort(lam1), np.sort(lam2)
    m = min(len(a), len(b))
    return float(np.mean(np.abs(a[:m] - b[:m]) ** p) ** (1 / p))


# ------------------------------------------------------------------ numpy MLP + DQN
class MLP:
    def __init__(self, sizes, rng, lr=1e-3):
        self.W = [rng.normal(0, np.sqrt(2.0 / a), (a, b)) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b) for b in sizes[1:]]
        self.lr = lr
        self.m = [np.zeros_like(w) for w in self.W] + [np.zeros_like(b) for b in self.b]
        self.v = [np.zeros_like(w) for w in self.W] + [np.zeros_like(b) for b in self.b]
        self.t = 0

    def forward(self, X, keep=False):
        hs = [X]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            X = X @ W + b
            if i < len(self.W) - 1:
                X = np.maximum(X, 0)
            hs.append(X)
        return (X, hs) if keep else X

    def step(self, X, A, target):
        """One Adam step on 0.5*mean (Q(s,a)-target)^2 for the taken actions."""
        Q, hs = self.forward(X, keep=True)
        n = len(X)
        g = np.zeros_like(Q)
        g[np.arange(n), A] = (Q[np.arange(n), A] - target) / n
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        for i in reversed(range(len(self.W))):
            gW[i] = hs[i].T @ g; gb[i] = g.sum(0)
            if i > 0:
                g = (g @ self.W[i].T) * (hs[i] > 0)
        self.t += 1
        params = self.W + self.b; grads = gW + gb
        for k, (p, gr) in enumerate(zip(params, grads)):
            self.m[k] = 0.9 * self.m[k] + 0.1 * gr
            self.v[k] = 0.999 * self.v[k] + 0.001 * gr ** 2
            mh = self.m[k] / (1 - 0.9 ** self.t); vh = self.v[k] / (1 - 0.999 ** self.t)
            p -= self.lr * mh / (np.sqrt(vh) + 1e-8)

    def copy_from(self, o):
        self.W = [w.copy() for w in o.W]; self.b = [b.copy() for b in o.b]


# reward matrix r_t = R_prevention - C_operation, rows: attack-active (0/1), cols: action (illustrative)
REWARD = np.array([
    # no-op  rate  block  pad
    [0.0, -0.3, -1.0, -0.2],       # benign window: any action costs collateral
    [-1.0, 0.2, 0.7, 0.1],         # attack window: acting prevents (R_prev) minus cost
])


class DQNAgent:
    def __init__(self, state_dim, rng, hidden=(256, 128, 64), replay=100_000, target_every=1000,
                 gamma=0.0, lr=1e-3, batch=64):
        self.rng = rng
        self.q = MLP([state_dim, *hidden, len(ACTIONS)], rng, lr)
        self.qt = MLP([state_dim, *hidden, len(ACTIONS)], rng, lr); self.qt.copy_from(self.q)
        self.cap, self.target_every, self.gamma, self.batch = replay, target_every, gamma, batch
        self.S = np.zeros((0, state_dim)); self.A = np.zeros(0, int); self.R = np.zeros(0); self.S2 = np.zeros((0, state_dim))
        self.steps = 0

    def act(self, s, eps):
        if self.rng.random() < eps:
            return int(self.rng.integers(len(ACTIONS)))
        return int(np.argmax(self.q.forward(s[None])[0]))

    def remember(self, s, a, r, s2):
        self.S = np.vstack([self.S, s])[-self.cap:]; self.A = np.append(self.A, a)[-self.cap:]
        self.R = np.append(self.R, r)[-self.cap:]; self.S2 = np.vstack([self.S2, s2])[-self.cap:]

    def learn(self):
        if len(self.A) < self.batch:
            return
        i = self.rng.integers(0, len(self.A), self.batch)
        tgt = self.R[i] + self.gamma * self.qt.forward(self.S2[i]).max(1)
        self.q.step(self.S[i], self.A[i], tgt)
        self.steps += 1
        if self.steps % self.target_every == 0:
            self.qt.copy_from(self.q)
