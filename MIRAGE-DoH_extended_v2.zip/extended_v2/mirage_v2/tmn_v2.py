"""Topological Memory Network, Sec 3.6 (Eqs. 6-10).

 - filtrations and persistence diagrams: mirage_v2/topology_v2.py (Eqs. 6-8)
 - LSTM-attention encoder over a sequence of diagrams (Eq. 9): numpy LSTM cell
   with fixed random recurrent weights (echo-state style) and an attention
   read-out over diagram points; only the logistic read-out is trained. This is
   a deliberately light stand-in for a trained LSTM-attention network.
 - traffic-graph construction and multi-hop chain memory (Sec 3.6, Table 6 row 4):
   hop edges observed in separate windows are accumulated, so a relay loop that
   no single window shows completely can still close in memory.
"""
import numpy as np
from . import topology_v2 as topo

CAP = 1.2


def diagram_points(dgm, m=8):
    """Top-m H1 points by lifetime as rows [birth, death(capped), lifetime]."""
    d = topo.capped(dgm, CAP)
    if len(d) == 0:
        return np.zeros((0, 3))
    life = d[:, 1] - d[:, 0]
    o = np.argsort(-life)[:m]
    return np.column_stack([d[o], life[o]])


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


class TMNEncoder:
    """h_t = LSTM(h_{t-1}, Attn(D_topo, x_t))  with fixed random weights."""

    def __init__(self, hidden=24, in_dim=3 + 20, seed=0):
        r = np.random.default_rng(seed)
        self.H, self.in_dim = hidden, in_dim
        s = 1.0 / np.sqrt(hidden)
        self.Wx = r.normal(0, s, (4 * hidden, in_dim))
        Q, _ = np.linalg.qr(r.normal(size=(hidden, hidden)))
        self.Wh = np.vstack([Q * 0.9 for _ in range(4)])
        self.b = np.zeros(4 * hidden); self.b[hidden:2 * hidden] = 1.0       # forget-gate bias
        self.q = r.normal(0, 1, 3)                                           # attention query on [b,d,life]
        self.mu = None

    def attn(self, pts):
        if len(pts) == 0:
            return np.zeros(3)
        a = np.exp(pts @ self.q * 2.0); a /= a.sum()
        return a @ pts

    def step(self, h, c, x):
        z = self.Wx @ x + self.Wh @ h + self.b
        H = self.H
        i, f, g, o = sigmoid(z[:H]), sigmoid(z[H:2 * H]), np.tanh(z[2 * H:3 * H]), sigmoid(z[3 * H:])
        c = f * c + i * g
        return o * np.tanh(c), c

    def encode(self, dgms, xs):
        """dgms: list of H1 diagrams (one per time step); xs: (T, in_dim-3) window features."""
        h = np.zeros(self.H); c = np.zeros(self.H)
        for d, x in zip(dgms, xs):
            v = np.concatenate([self.attn(diagram_points(d)), x])
            h, c = self.step(h, c, v)
        return h


class Logistic:
    def fit(self, X, y, iters=600, lr=0.2, l2=1e-3):
        self.mu, self.sd = X.mean(0), X.std(0) + 1e-9
        Z = (X - self.mu) / self.sd
        w = np.zeros(Z.shape[1]); b = 0.0
        for _ in range(iters):
            p = sigmoid(Z @ w + b)
            w -= lr * (Z.T @ (p - y) / len(y) + l2 * w); b -= lr * (p - y).mean()
        self.w, self.b = w, b
        return self

    def score(self, X):
        return ((X - self.mu) / self.sd) @ self.w + self.b


# ---------------------------------------------------------------- traffic graph
def temporal_weight(dt, tau=0.1):
    """Eq. (20) edge weight w = exp(-dt/tau); the filtration uses d = 1 - w."""
    return np.exp(-np.asarray(dt, float) / tau)


def background_graph(n, rng, hub_frac=0.08):
    """Band graph over n time-ordered flow vertices (edges to the next two
    flows) plus a few long-range hub edges. Filtration value d = 1 - exp(-dt/tau)."""
    t = np.cumsum(rng.lognormal(-1.0, 1.1, n))
    E = []
    for i in range(n):
        for k in (1, 2):
            if i + k < n:
                E.append((i, i + k, 1 - float(temporal_weight(t[i + k] - t[i]))))
    for _ in range(int(hub_frac * n)):
        a, b = rng.integers(0, n, 2)
        if abs(a - b) > 3:
            E.append((int(a), int(b), 1 - float(temporal_weight(abs(t[a] - t[b])))))
    return t, E


def add_relay_chain(E, n, L, rng, hop_dt=0.03):
    """Append a closed relay loop of L tightly timed hops (client -> relay_1 ->
    ... -> relay_L -> client's return path) attached to the background by a
    single edge, so the loop is a cycle of its own: born early (small weights),
    never filled by triangles. Returns (edges, loop_edges, n_nodes)."""
    a = int(rng.integers(0, n))
    nodes = [n + i for i in range(L)]
    chain = []
    for u, v in zip(nodes, nodes[1:] + nodes[:1]):
        dt = abs(rng.normal(hop_dt, 0.01))
        chain.append((u, v, 1 - float(temporal_weight(dt))))
    attach = (a, nodes[0], 1 - float(temporal_weight(rng.lognormal(-1.0, 1.1))))
    return E + chain + [attach], chain, n + L


def chain_score(n_nodes, edges):
    """Largest H1 lifetime with infinite deaths capped: tight, closed relay
    loops are born early and never die."""
    dg = topo.flag_persistence(n_nodes, edges)[1]
    d = topo.capped(dg, CAP)
    return float((d[:, 1] - d[:, 0]).max()) if len(d) else 0.0


def observe(chain, p_obs, rng):
    return [e for e in chain if rng.random() < p_obs]
