"""Causal Counterfactual Environment, Sec 3.8 (Eqs. 14-16).

Exact inference on small discrete structural causal models M = (U, V, F):
  - observational P(Y | X)                 (confounded by U)
  - interventional P(Y | do(X=x'))         Eq. (15), by summing over U
  - counterfactual P(Y_{x'} | X=x, Y=y)    abduction -> action -> prediction
  - hardening choice P* = argmax E[R]      Eq. (16), over a finite set of interventions
All probabilities are exact (enumeration), so results are free of sampling error.
Scenario parameters in `SCENARIOS` are illustrative assumptions, not measurements.
"""
import itertools
from dataclasses import dataclass, field


@dataclass
class SCM:
    exo: dict                      # name -> {value: prob}
    mech: dict                     # endogenous name -> (parents, f(parent_values)->{value: prob})
    order: list                    # endogenous topological order

    def joint(self, do=None):
        do = do or {}
        names = list(self.exo)
        out = {}
        for ue in itertools.product(*[list(self.exo[n].items()) for n in names]):
            pu = 1.0; assign = {}
            for n, (v, p) in zip(names, ue):
                assign[n] = v; pu *= p
            rows = [(assign, pu)]
            for var in self.order:
                new = []
                for a, p in rows:
                    if var in do:
                        dist = {do[var]: 1.0}
                    else:
                        parents, f = self.mech[var]
                        dist = f(*[a[q] for q in parents])
                    for v, pv in dist.items():
                        if pv > 0:
                            b = dict(a); b[var] = v; new.append((b, p * pv))
                rows = new
            for a, p in rows:
                key = tuple(sorted(a.items()))
                out[key] = out.get(key, 0.0) + p
        return out

    @staticmethod
    def prob(joint, event, given=None):
        ok = lambda a, c: all(dict(a)[k] == v for k, v in c.items())
        num = sum(p for a, p in joint.items() if ok(a, event) and (given is None or ok(a, given)))
        den = sum(p for a, p in joint.items() if given is None or ok(a, given))
        return num / den if den > 0 else float("nan")

    def p_obs(self, y, x):                       # P(Y=y | X=x)
        (yn, yv), (xn, xv) = y, x
        return self.prob(self.joint(), {yn: yv}, {xn: xv})

    def p_do(self, y, x):                        # Eq. (15)
        (yn, yv), (xn, xv) = y, x
        return self.prob(self.joint(do={xn: xv}), {yn: yv})

    def p_do_adjust(self, y, x, u_name):
        """Eq. (15) literally: sum_u P(Y | do(X=x'), U=u) P(U=u)."""
        (yn, yv), (xn, xv) = y, x
        J = self.joint(do={xn: xv})
        return sum(pu * self.prob(J, {yn: yv}, {u_name: u}) for u, pu in self.exo[u_name].items())

    def counterfactual(self, y, x_new, evidence, u_name):
        """P(Y_{x_new}=y | evidence) for exogenous u_name: abduction on the observed
        factual world, action do(X=x_new), prediction."""
        (yn, yv), (xn, xv) = y, x_new
        Jf = self.joint()
        pu = {u: self.prob(Jf, {u_name: u}, evidence) for u in self.exo[u_name]}
        Jc = self.joint(do={xn: xv})
        return sum(p * self.prob(Jc, {yn: yv}, {u_name: u}) for u, p in pu.items() if p == p)


def attack_scm(p_intent, p_vec_mal, p_vec_ben, p_comp):
    """U_intent -> X (attack vector exposed) -> Y (compromise); U_intent -> Y directly.
    p_comp[(x, u)] = P(Y=1 | X=x, U=u)."""
    exo = {"intent": {1: p_intent, 0: 1 - p_intent}}
    def fx(u):
        p = p_vec_mal if u == 1 else p_vec_ben
        return {1: p, 0: 1 - p}
    def fy(x, u):
        p = p_comp[(x, u)]
        return {1: p, 0: 1 - p}
    return SCM(exo, {"X": (["intent"], fx), "Y": (["X", "intent"], fy)}, ["X", "Y"])


# illustrative parameters: (p_intent, P(X=1|mal), P(X=1|benign), P(Y=1|X,U))
SCENARIOS = {
    "protocol downgrade (TLS1.3->1.2 via ECS)": dict(
        p_intent=0.25, p_vec_mal=0.85, p_vec_ben=0.05,
        p_comp={(1, 1): 0.70, (0, 1): 0.10, (1, 0): 0.01, (0, 0): 0.001},
        actions={"disable TLS1.2 fallback": ("X", 0, 0.004, 0.97), "strip ECS from upstream": ("X", 0, 0.002, 0.80),
                 "none": (None, None, 0.0, 0.0)}),
    "AI mimicry (rule-evasion)": dict(
        p_intent=0.20, p_vec_mal=0.75, p_vec_ben=0.10,
        p_comp={(1, 1): 0.55, (0, 1): 0.08, (1, 0): 0.02, (0, 0): 0.002},
        actions={"enforce 256-bit nonce + new session": ("X", 0, 0.006, 0.90), "tighten entropy rules": ("X", 0, 0.001, 0.60),
                 "none": (None, None, 0.0, 0.0)}),
    "timing probe on key setup": dict(
        p_intent=0.10, p_vec_mal=0.90, p_vec_ben=0.15,
        p_comp={(1, 1): 0.40, (0, 1): 0.05, (1, 0): 0.01, (0, 0): 0.001},
        actions={"escalate shard to Pi_2": ("X", 0, 0.01, 0.95), "add lattice noise": ("X", 0, 0.003, 0.70),
                 "none": (None, None, 0.0, 0.0)}),
}


def choose_hardening(spec, breach_cost=100.0):
    """Eq. (16): P* = argmax E[R], R = -(breach_cost * P(Y=1 | do(action)) + operating cost)."""
    scm = attack_scm(spec["p_intent"], spec["p_vec_mal"], spec["p_vec_ben"], spec["p_comp"])
    rows = []
    base = scm.prob(scm.joint(), {"Y": 1})
    for name, (var, val, cost, eff) in spec["actions"].items():
        # stochastic intervention: succeeds with probability eff (do(X=val)), else the natural mechanism
        risk = (eff * scm.p_do(("Y", 1), (var, val)) + (1 - eff) * base) if var else base
        rows.append((name, risk, -(breach_cost * risk + 100 * cost)))
    best = max(rows, key=lambda r: r[2])
    return rows, best, scm
