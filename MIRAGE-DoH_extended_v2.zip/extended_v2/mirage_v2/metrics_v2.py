"""Evaluation metrics of Sec 3.12 that are computable, plus interval estimates.

Implemented: CTAI (Eq. 29), throughput model (Eq. 31), spectral Wasserstein proxy
(see sgi_v2), Wilson / Clopper-Pearson intervals, ROC/AUC.
Not implemented, with reasons: Eq. (27) graphon-coupling Wasserstein (no algorithm given;
replaced by the 1-D spectral proxy), Eq. (28) QR_MCS (the tensor product of a probability
with an advantage ratio is not defined), Eq. (30) QLR (supremum over all quantum algorithms).
"""
import math
import numpy as np


def wilson(k, n, z=1.959964):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def clopper_pearson_upper(k, n, conf=0.95):
    from scipy.stats import beta
    return 1.0 if k >= n else float(beta.ppf(conf, k + 1, n - k))


def min_negatives_for_fpr(bound, conf=0.95, fp=0):
    lo, hi = 1, 10
    while clopper_pearson_upper(fp, hi, conf) > bound:
        hi *= 2
    while lo < hi:
        mid = (lo + hi) // 2
        if clopper_pearson_upper(fp, mid, conf) <= bound:
            hi = mid
        else:
            lo = mid + 1
    return lo


def roc(scores, y):
    s = np.asarray(scores, float); y = np.asarray(y).astype(bool)
    g = np.concatenate([[np.inf], np.sort(np.unique(s))[::-1], [-np.inf]])
    P, N = y.sum(), (~y).sum()
    return g, np.array([((s > t) & y).sum() / P for t in g]), np.array([((s > t) & ~y).sum() / N for t in g])


def auc(scores, y):
    s = np.asarray(scores, float); y = np.asarray(y).astype(bool)
    r = np.argsort(np.argsort(s)) + 1.0
    # average ranks for ties
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    csum = np.cumsum(cnt); avg = csum - (cnt - 1) / 2.0
    r = avg[inv]
    n1, n0 = y.sum(), (~y).sum()
    return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def ctai(acc, fpr, latency, a1=1.0, a2=1.0, a3=1.0):
    """Eq. (29): mean over t of a1*Acc_t - a2*FPR_t - a3*Latency_t."""
    acc, fpr, latency = (np.asarray(v, float) for v in (acc, fpr, latency))
    return float(np.mean(a1 * acc - a2 * fpr - a3 * latency))


def throughput(per_query_times, c_parallel):
    """Eq. (31) as typeset: T_total = (sum_i lambda_i)^-1 * C_parallel. Summing per-class
    processing times is only meaningful if lambda_i is the mix-weighted mean time; this
    helper therefore takes the class times AND uses their plain mean to stay dimensionally
    consistent (queries/second per instance times instances)."""
    lam = float(np.mean(per_query_times))
    return c_parallel / lam


def instances_for(qps, per_query_s):
    return qps * per_query_s
