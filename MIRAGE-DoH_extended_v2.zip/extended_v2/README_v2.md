# MIRAGE-DoH Chapter 3: extended artifact (v2)

Everything lives under `extended_v2/`; every file name ends in `_v2`, so nothing replaces an existing file.

| Path | Content |
|---|---|
| `mirage_v2/` | reference implementations: traffic generator, persistent homology, TMN, CMA, ML-KEM, hybrid combiner and policy, causal engine, spectral graph + DQN, SE(3) flow, metrics |
| `experiments/mirage_detection_experiments_v2.py` | D1-D6: detector comparison, curriculum, TMN memory, DQN defender, full-factorial ablation, jump test |
| `experiments/mirage_crypto_causal_experiments_v2.py` | C1-C7: ML-KEM, combiner, morph-time budget, policy, causal engine, SE(3) |
| `experiments/mirage_system_report_v2.py` | S1-S6 + consolidated HTML/Markdown report |
| `results_v2/` | outputs of those runs (CSV, PNG, Markdown, HTML report) |
| `tests/` | 28 unit tests |
| `docs/` | equation-to-code map, hardware dependency matrix |

## Run

```bash
pip install -r requirements_v2.txt
make test
python3 experiments/mirage_crypto_causal_experiments_v2.py --out results_v2/crypto      # ~15 s
# detection suite is resumable by stage (about 25 min on one core in total):
python3 experiments/mirage_detection_experiments_v2.py --only data --out results_v2/detect
python3 experiments/mirage_detection_experiments_v2.py --only d1   --out results_v2/detect
for L in 0.0 10.0 100.0 1000.0; do python3 experiments/mirage_detection_experiments_v2.py --only d2 --lam $L --out results_v2/detect; done
python3 experiments/mirage_detection_experiments_v2.py --only d3,d4,d6,report --out results_v2/detect
python3 experiments/mirage_system_report_v2.py --detect results_v2/detect --crypto results_v2/crypto --out results_v2/system
```

## Scope

Traffic is synthetic; baselines are scikit-learn models, not the thesis CNN-LSTM; ML-KEM is an educational
implementation that is not validated against official test vectors; Classic McEliece is a byte-size model
only; Loihi 2, FPGA and A100 results are not reproduced. Tables in `results_v2/` are therefore not Tables 8-12.
