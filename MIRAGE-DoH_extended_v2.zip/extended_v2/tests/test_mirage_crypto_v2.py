import os, unittest
import numpy as np
from mirage_v2.mlkem_v2 import MLKEM, PARAMS, ntt, ntt_inv, compress, decompress, Q
from mirage_v2 import mcs_v2 as mcs

SIZES = {"ML-KEM-512": (800, 1632, 768), "ML-KEM-768": (1184, 2400, 1088), "ML-KEM-1024": (1568, 3168, 1568)}


class TestMLKEM(unittest.TestCase):
    def test_ntt_roundtrip(self):
        f = list(np.random.default_rng(0).integers(0, Q, 256))
        self.assertEqual(ntt_inv(ntt(f)), f)

    def test_compress_error_bound(self):
        for d in (1, 4, 10):
            for x in range(0, Q, 7):
                e = (decompress(compress(x, d), d) - x + Q // 2) % Q - Q // 2
                self.assertLessEqual(abs(e), int(np.ceil(Q / 2 ** (d + 1))))

    def test_sizes_roundtrip_rejection(self):
        for name in PARAMS:
            k = MLKEM(name); ek, dk = k.keygen(); K, c = k.encaps(ek)
            self.assertEqual((len(ek), len(dk), len(c)), SIZES[name])
            self.assertEqual(k.decaps(dk, c), K)
            bad = bytearray(c); bad[3] ^= 1
            Kb = k.decaps(dk, bytes(bad))
            self.assertNotEqual(Kb, K); self.assertEqual(Kb, k.decaps(dk, bytes(bad)))

    def test_deterministic_given_seeds(self):
        k = MLKEM("ML-KEM-768"); d, z, m = b"\x01" * 32, b"\x02" * 32, b"\x03" * 32
        e1, d1 = k.keygen(d, z); e2, d2 = k.keygen(d, z)
        self.assertEqual((e1, d1), (e2, d2)); self.assertEqual(k.encaps(e1, m), k.encaps(e2, m))


class TestMCS(unittest.TestCase):
    def test_policy_floor_and_order(self):
        self.assertEqual([mcs.select_level(x, .3, .7) for x in (0, .3, .31, .7, .71, 1)], [0, 0, 1, 1, 2, 2])
        with self.assertRaises(ValueError):
            mcs.select_level(.5, .8, .2)
        for r in np.random.default_rng(0).random(1000):
            self.assertGreaterEqual(mcs.select_level(r, .3, .7), 0)

    def test_adaptive_thresholds_clipped(self):
        a = mcs.AdaptiveThresholds()
        for _ in range(2000):
            g1, g2 = a.update(1.0)
        self.assertLessEqual(g1, a.hi[0]); self.assertLessEqual(g2, a.hi[1])

    def test_combiner_binds_everything(self):
        base = mcs.combine(b"a" * 32, b"b" * 32, b"c" * 8, b"d" * 8, b"x")
        for args in [(b"A" * 32, b"b" * 32, b"c" * 8, b"d" * 8, b"x"), (b"a" * 32, b"B" * 32, b"c" * 8, b"d" * 8, b"x"),
                     (b"a" * 32, b"b" * 32, b"C" * 8, b"d" * 8, b"x"), (b"a" * 32, b"b" * 32, b"c" * 8, b"D" * 8, b"x"),
                     (b"a" * 32, b"b" * 32, b"c" * 8, b"d" * 8, b"y")]:
            self.assertNotEqual(mcs.combine(*args), base)

    def test_length_prefix_prevents_boundary_shift(self):
        self.assertNotEqual(mcs.combine(b"ab", b"c", b"", b"", b""), mcs.combine(b"a", b"bc", b"", b"", b""))

    @unittest.skipUnless(mcs.HAVE_CRYPTO, "cryptography not installed")
    def test_handshake_all_levels(self):
        for L in (0, 1, 2):
            h = mcs.handshake(L)
            self.assertEqual(len(h.key), 32)
        self.assertGreater(mcs.handshake(2).wire_c2s, 1_000_000)
        self.assertLess(mcs.handshake(2, pre_provisioned_pk2=True).wire_c2s, 4000)

    @unittest.skipUnless(mcs.HAVE_CRYPTO, "cryptography not installed")
    def test_aead_tamper(self):
        k = os.urandom(32); b = bytearray(mcs.seal(k, b"m", b"ad")); b[-1] ^= 1
        with self.assertRaises(Exception):
            mcs.open_(k, bytes(b), b"ad")

    def test_size_model(self):
        m = mcs.SizeModelKEM(); pk, sk = m.keygen(); ss, ct = m.encaps(pk)
        self.assertEqual((len(pk), len(ct)), (1_044_992, 208)); self.assertEqual(m.decaps(sk, ct), ss)


if __name__ == "__main__":
    unittest.main()
