import unittest
import numpy as np
from mirage_v2 import traffic_v2 as tv, topology_v2 as topo, tmn_v2 as tmn, cma_v2 as cma, metrics_v2 as mt
from mirage_v2 import cce_v2 as cce, levy_se3_v2 as se3, sgi_v2 as sgi


class TestTraffic(unittest.TestCase):
    def test_features_finite_all_kinds(self):
        rng = np.random.default_rng(0)
        for k in tv.KINDS:
            f = tv.window_features(tv.gen_window(k, rng))
            self.assertEqual(f.shape, (tv.D,)); self.assertTrue(np.all(np.isfinite(f)))

    def test_downgrade_has_tls12(self):
        rng = np.random.default_rng(1)
        i = tv.FEATURE_NAMES.index("tls12_frac")
        d = np.mean([tv.window_features(tv.gen_window("downgrade", rng))[i] for _ in range(40)])
        b = np.mean([tv.window_features(tv.gen_window("benign", rng))[i] for _ in range(40)])
        self.assertGreater(d, b + 0.2)


class TestTopology(unittest.TestCase):
    def test_flag_persistence_cycle_vs_triangle(self):
        E = [(i, (i + 1) % 6, .1) for i in range(6)] + [(6, 7, .2), (7, 8, .2), (6, 8, .2)]
        h1 = topo.flag_persistence(9, E)[1]
        self.assertEqual(len(h1), 1); self.assertTrue(np.isinf(h1[0, 1]))     # hexagon persists, triangle filled

    def test_vr_precomputed_matches_points(self):
        th = np.linspace(0, 2 * np.pi, 20, endpoint=False); P = np.c_[np.cos(th), np.sin(th)]
        from scipy.spatial.distance import pdist, squareform
        a = topo.vr_persistence(P, 2.0)[1]; b = topo.vr_persistence(squareform(pdist(P)), 2.0, precomputed=True)[1]
        self.assertTrue(np.allclose(np.sort(a, 0), np.sort(b, 0)))


class TestTMN(unittest.TestCase):
    def test_relay_loop_detected_and_background_not(self):
        rng = np.random.default_rng(2)
        bg, lp = [], []
        for _ in range(15):
            t, E = tmn.background_graph(100, rng); bg.append(tmn.chain_score(100, E))
            E2, ch, N = tmn.add_relay_chain(E, 100, 40, rng); lp.append(tmn.chain_score(N, E2))
        self.assertLess(max(bg), min(lp))

    def test_missing_hop_breaks_loop(self):
        rng = np.random.default_rng(3)
        t, E = tmn.background_graph(100, rng)
        E2, ch, N = tmn.add_relay_chain(E, 100, 30, rng)
        full = tmn.chain_score(N, E2); cut = tmn.chain_score(N, [e for e in E2 if e != ch[0]])
        self.assertGreater(full, cut)

    def test_encoder_shape(self):
        enc = tmn.TMNEncoder(hidden=8, in_dim=3 + 5)
        h = enc.encode([np.array([[0.1, np.inf]])] * 3, np.zeros((3, 5)))
        self.assertEqual(h.shape, (8,))


class TestCMA(unittest.TestCase):
    def test_es_learns_separable_task(self):
        rng = np.random.default_rng(0)
        X = np.vstack([rng.normal(0, 1, (200, cma.D)), rng.normal(3, 1, (100, cma.D))]); y = np.r_[np.zeros(200), np.ones(100)]
        th = cma.es_train(cma.init(rng), X, y, np.zeros(300), rng, gens=150)
        self.assertGreater(cma.f1_auc(th, X, y)[0], 0.95)

    def test_fisher_penalty_zero_at_anchor_and_positive_away(self):
        rng = np.random.default_rng(1)
        th = cma.init(rng); F = np.abs(rng.normal(size=cma.NP))
        self.assertEqual(cma.r_cat(th, th, F), 0.0); self.assertGreater(cma.r_cat(th + 0.1, th, F), 0.0)

    def test_fisher_nonnegative(self):
        rng = np.random.default_rng(2)
        th = cma.init(rng); X = rng.normal(size=(50, cma.D)); y = (rng.random(50) > .5).astype(float)
        self.assertTrue(np.all(cma.fisher_diag(th, X, y) >= 0))


class TestCCEandSE3(unittest.TestCase):
    def test_do_equals_adjustment(self):
        for sp in cce.SCENARIOS.values():
            scm = cce.attack_scm(sp["p_intent"], sp["p_vec_mal"], sp["p_vec_ben"], sp["p_comp"])
            self.assertAlmostEqual(scm.p_do(("Y", 1), ("X", 1)), scm.p_do_adjust(("Y", 1), ("X", 1), "intent"), places=12)
            self.assertGreater(scm.p_obs(("Y", 1), ("X", 1)), scm.p_do(("Y", 1), ("X", 1)))   # positive confounding

    def test_joint_sums_to_one(self):
        sp = list(cce.SCENARIOS.values())[0]
        scm = cce.attack_scm(sp["p_intent"], sp["p_vec_mal"], sp["p_vec_ben"], sp["p_comp"])
        self.assertAlmostEqual(sum(scm.joint().values()), 1.0)

    def test_se3_stays_on_group(self):
        r = se3.Rerandomizer(seed=0)
        for _ in range(500):
            r.step(.4, .5, 1, .3)
        self.assertLess(r.group_error(), 1e-10)

    def test_bns_separates_jumps(self):
        rng = np.random.default_rng(0)
        x, _ = se3.levy_path(2000, 1.0, 0.02, 6.0, rng)
        self.assertGreater(se3.bns_jump_stat(x), se3.bns_jump_stat(rng.normal(size=2000)) + 0.05)


class TestSGIandMetrics(unittest.TestCase):
    def test_spectrum_permutation_invariant_and_nonnegative(self):
        ts = np.cumsum(np.random.default_rng(0).exponential(0.05, 40))
        a = sgi.spectral_state(ts); b = sgi.spectral_state(np.random.default_rng(1).permutation(ts))
        self.assertTrue(np.allclose(a, b, atol=1e-9)); self.assertTrue(np.all(a > -1e-9))

    def test_dqn_learns_two_state_bandit(self):
        rng = np.random.default_rng(0)
        ag = sgi.DQNAgent(2, rng, hidden=(16,), target_every=50)
        for i in range(1500):
            active = int(rng.random() < .5); s = np.array([active, 1 - active], float) + rng.normal(0, .05, 2)
            a = ag.act(s, max(.05, 1 - i / 800)); ag.remember(s, a, sgi.REWARD[active, a], s); ag.learn()
        self.assertEqual(int(np.argmax(ag.q.forward(np.array([[1., 0.]]))[0])) != 0, True)
        self.assertEqual(int(np.argmax(ag.q.forward(np.array([[0., 1.]]))[0])), 0)

    def test_metrics(self):
        self.assertAlmostEqual(mt.ctai([1.0], [0.0], [0.0]), 1.0)
        self.assertTrue(370_000 < mt.min_negatives_for_fpr(8e-6) < 380_000)
        self.assertAlmostEqual(mt.auc([0, 1, 2, 3], [0, 0, 1, 1]), 1.0)


if __name__ == "__main__":
    unittest.main()
